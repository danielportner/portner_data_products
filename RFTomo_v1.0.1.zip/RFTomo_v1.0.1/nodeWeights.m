function [ wts ] = nodeWeights(x,y,z,indx,domain) ;

% Determines the weighting scheme for the surrounding nodes of a point
%   based on 3-component distances
%
% Written DEP 13 May 2020, after L. Wagner

wts = zeros(length(indx),1) ;

% Extract the position at each node
xs = domain.mx(indx) ;
ys = domain.my(indx) ;
zs = domain.mz(indx) ;

% Determine bounding values
x1 = min(xs) ; x2 = max(xs) ;
y1 = min(ys) ; y2 = max(ys) ;
z1 = min(zs) ; z2 = max(zs) ;

% Determine the x, y, and z weights to each
xwt1 = 1-(abs(x1-x)/domain.dx) ; xwt2 = 1-(abs(x2-x)/domain.dx) ;
ywt1 = 1-(abs(y1-y)/domain.dy) ; ywt2 = 1-(abs(y2-y)/domain.dy) ;
zwt1 = 1-(abs(z1-z)/domain.dz) ; zwt2 = 1-(abs(z2-z)/domain.dz) ;

for i = 1:length(indx)
    if xs(i) == x1
        x_use = xwt1 ;
    elseif xs(i) == x2
        x_use = xwt2 ;
    end
    if ys(i) == y1
        y_use = ywt1 ;
    elseif ys(i) == y2
        y_use = ywt2 ;
    end
    if zs(i) == z1
        z_use = zwt1 ;
    elseif zs(i) == z2
        z_use = zwt2 ;
    end
    wts(i) = x_use*y_use*z_use ;
end

end

