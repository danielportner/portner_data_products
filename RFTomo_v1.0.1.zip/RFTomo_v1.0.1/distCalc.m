function [ dist ] = distCalc(lon1,lat1,rad1,lon2,lat2,rad2) ;

% Calculates the Cartesian distance between two points within a sphere
%
% Written DEP 27 Feb 2020

% Convert locations to radians, colatitude
theta1 = deg2rad(90 - lat1) ;
phi1 = deg2rad(lon1) ;

theta2 = deg2rad(90 - lat2) ;
phi2 = deg2rad(lon2) ;

% Convert locations to Cartesian coordinates
x1 = rad1 .* sin(theta1) .* cos(phi1) ;
y1 = rad1 .* sin(theta1) .* sin(phi1) ;
z1 = rad1 .* cos(theta1) ;

x2 = rad2 .* sin(theta2) .* cos(phi2) ;
y2 = rad2 .* sin(theta2) .* sin(phi2) ;
z2 = rad2 .* cos(theta2) ;

dist = ((x2-x1).^2 + (y2-y1).^2 + (z2-z1).^2).^(1/2) ;

end

