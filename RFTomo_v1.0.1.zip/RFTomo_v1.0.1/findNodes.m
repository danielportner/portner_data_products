function [ indx ] = findNodes(x,y,z,domain) ;

% Finds the grid nodes surrounding a given location and returns
%   their model vector indices
%
% Written DEP 28 Feb 2020
% Edited DEP 12 May 2020 to accomodate if a location is in a node plane

xeq = 0 ; yeq = 0 ; zeq = 0 ;
% Find bounding nodes in x
x1 = max(domain.modx(domain.modx-x<=0)) ;
x2 = min(domain.modx(domain.modx-x>=0)) ;
if x1 == x || x2 == x
    xeq = 1 ;
end

% Find bounding nodes in y
y1 = max(domain.mody(domain.mody-y<=0)) ;
y2 = min(domain.mody(domain.mody-y>=0)) ;
if y1 == y || y2 == y
    yeq = 1 ;
end

% Find bounding nodes in z
z1 = max(domain.modz(domain.modz-z<=0)) ;
z2 = min(domain.modz(domain.modz-z>=0)) ;
if z1 == z || z2 == z
    zeq = 1 ;
end

if xeq == 1
    if yeq == 1
        if zeq == 1
            indx1 = domain.mind(domain.mx==x & domain.my==y & domain.mz==z) ;
            indx = indx1 ;
        elseif zeq == 0
            indx1 = domain.mind(domain.mx==x & domain.my==y & domain.mz==z1) ;
            indx2 = domain.mind(domain.mx==x & domain.my==y & domain.mz==z2) ;
            indx = [ indx1 ; indx2 ] ;
        end
    elseif yeq == 0
        if zeq == 1
            indx1 = domain.mind(domain.mx==x & domain.my==y1 & domain.mz==z) ;
            indx2 = domain.mind(domain.mx==x & domain.my==y2 & domain.mz==z) ;
            indx = [ indx1 ; indx2 ] ;
        elseif zeq == 0
            indx1 = domain.mind(domain.mx==x & domain.my==y1 & domain.mz==z1) ;
            indx2 = domain.mind(domain.mx==x & domain.my==y1 & domain.mz==z2) ;
            indx3 = domain.mind(domain.mx==x & domain.my==y2 & domain.mz==z1) ;
            indx4 = domain.mind(domain.mx==x & domain.my==y2 & domain.mz==z2) ;
            indx = [ indx1 ; indx2 ; indx3 ; indx4 ] ;
        end
    end
elseif xeq == 0
    if yeq == 1
        if zeq == 1
            indx1 = domain.mind(domain.mx==x1 & domain.my==y & domain.mz==z) ;
            indx2 = domain.mind(domain.mx==x2 & domain.my==y & domain.mz==z) ;
            indx = [ indx1 ; indx2 ] ;
        elseif zeq == 0
            indx1 = domain.mind(domain.mx==x1 & domain.my==y & domain.mz==z1) ;
            indx2 = domain.mind(domain.mx==x1 & domain.my==y & domain.mz==z2) ;
            indx3 = domain.mind(domain.mx==x2 & domain.my==y & domain.mz==z1) ;
            indx4 = domain.mind(domain.mx==x2 & domain.my==y & domain.mz==z2) ;
            indx = [ indx1 ; indx2 ; indx3 ; indx4 ] ;
        end
    elseif yeq == 0
        if zeq == 1
            indx1 = domain.mind(domain.mx==x1 & domain.my==y1 & domain.mz==z) ;
            indx2 = domain.mind(domain.mx==x1 & domain.my==y2 & domain.mz==z) ;
            indx3 = domain.mind(domain.mx==x2 & domain.my==y1 & domain.mz==z) ;
            indx4 = domain.mind(domain.mx==x2 & domain.my==y2 & domain.mz==z) ;
            indx = [ indx1 ; indx2 ; indx3 ; indx4 ] ;
        elseif zeq == 0
            indx1 = domain.mind(domain.mx==x1 & domain.my==y1 & domain.mz==z1) ;
            indx2 = domain.mind(domain.mx==x1 & domain.my==y1 & domain.mz==z2) ;
            indx3 = domain.mind(domain.mx==x1 & domain.my==y2 & domain.mz==z1) ;
            indx4 = domain.mind(domain.mx==x1 & domain.my==y2 & domain.mz==z2) ;
            indx5 = domain.mind(domain.mx==x2 & domain.my==y1 & domain.mz==z1) ;
            indx6 = domain.mind(domain.mx==x2 & domain.my==y1 & domain.mz==z2) ;
            indx7 = domain.mind(domain.mx==x2 & domain.my==y2 & domain.mz==z1) ;
            indx8 = domain.mind(domain.mx==x2 & domain.my==y2 & domain.mz==z2) ;
            indx = [ indx1 ; indx2 ; indx3 ; indx4 ; indx5 ; indx6 ; indx7 ; indx8 ] ;
        end
    end
end

end

