%---------- run_rftomo ----------%
%
% run_rftomo is a simple call script for a single run of rftomo
%   Parameters are defined herein
%

%% Define parameters
% Data file
delayFile = 'InputFiles/sampleInput_imush.dat' ; % Input data file

% Inversion parameters
n_iter = 5 ;

% data residual cutoff (s) - negative will be -1*cutoff
use_cutoff = true ; cutoff = 1.0 ;

% Damping
damp = 50 ; % epsilon^2 damping parameter

% Model domain parameters
origin = [ 46.20 -122.19 ] ; % Reference point for model domain
dx = 10 ; dy = 10 ; dz = 10 ; % Node spacing in x, y, and z dimensions
pad = 30 ; % Lateral distance beyond stations for model domain 
zrange = [ -10 60 ] ; % Depth range for model (negative is above sea level)

% Velocity model parameters
% vmod: refmod 1 = ak135, 2 = uniform crust with assigned Vs 
%   vmod = 2 requires a vs_crust value
vmod = 2  ; 
vs_crust = 3.70 ; % only for vmod = 2
% moho_type: 1 = flat Moho, 2 = pseudo-isostatic Moho, 3 = custom uploaded Moho
moho_type = 3 ; 
smoho = 44 ; % Starting moho depth (for moho_type 2, is Moho at sea level)

%% Run rftomo
rftomo_v1_0_1
save('Saved/tmp.mat','-v7.3') ;
