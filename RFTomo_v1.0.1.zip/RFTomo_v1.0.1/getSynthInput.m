% getSynthInput uses an input data file and a synthetic velocity model to
%   generate predicted Ps-P delay times. These are saved into a file that
%   can be used as input for a synthetic test.
%
% Written DEP 29 Feb 2020

outfile = 'InputFiles/sampleInput_synthetic.dat' ;

% Run forward problem given existing data file
[ d_synth, G ] = fwdCalc(data,domain,synth_model) ;

fid = fopen(outfile,'w+') ;
for i = 1:data.ray.nrays
    fprintf(fid,'%d %f %f %f %s %f %f %f %s %f\n', ...
        data.ray.evid(i),data.ray.evlat(i),data.ray.evlon(i),...
        data.ray.evdep(i),data.ray.stanm{i},data.ray.stalat(i),...
        data.ray.stalon(i),data.ray.stael(i),data.ray.ph{i},...
        d_synth(i));
end

fclose(fid) ;