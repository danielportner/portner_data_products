% makeSynthChecker is a script that uses an already established domain and
%   starting model to create a checkerboard synthetic model
%
% Written DEP 04 Jun 2020

v_type = 2 ; % 2 for Vs
dv = -0.25 ; % fractional velocity perturbation

nx = domain.nx ; ny = domain.ny ; nz = domain.nz ;

% 1 node width laterally
%cbx = [ 1 -1 ] ; cbx = repmat(cbx,1,nx) ;
%cby = [ 1 2 ] ; cby = repmat(cby,1,ny) ;
% 2 node width laterally
cbx = [ 1 1 -1 -1 ] ; cbx = repmat(cbx,1,nx) ;
cby = [ 1 1 2 2 ] ; cby = repmat(cby,1,ny) ;

% Define vertical distribution of checkers
% 1 is opposite polarity from 2
% Defined at depths of [ -10 0 10 20 30 40 50 60 ] in km
cbz = [ 0 1 1 0 2 2 0 0 ] ;
% The above example has two, two node-height checkers separated by one 
% neutral node. These checkers are at 0-10 and 30-40 km depth

cbx = cbx(1:nx) ; cby = cby(1:ny) ; cbz = cbz(1:nz) ;

cbxy = zeros(ny,length(cbx)) ;
for iy = 1:ny
    if cby(iy) == 1
        cbxy(iy,:) = cbx ;
    elseif cby(iy) == 2
        cbxy(iy,:) = -1*cbx ;
    end
end

cb = zeros(ny,nx,nz) ;
for iz = 1:nz
    if cbz(iz) == 1
        cb(:,:,iz) = cbxy ;
    elseif cbz(iz) == 2
        cb(:,:,iz) = -1*cbxy ;
    end
end

cb = reshape(cb,size(domain.mx)) ;
synth_model = smodel ;
synth_model(:,v_type) = synth_model(:,v_type).*(1+dv*cb) ;