function [ ray_coeffs ] = calcRayNodes(rays,domain,in_model)

% Takes a ray path and a model domain and calculates the
%   sensitivies of the ray to each node in the model domain
%
% After ray_trace_1D_NT and ray_nodes from B. Schmandt
%
% Written DEP 27 Feb 2020
% Edited DEP 20 Mar 2020 to accommodate multiple station paths in ray path
%   variable
% Edited DEP 12 May 2020 to accommodate if a mid-point is in a node plane
% Edited DEP 13 May 2020 to use a new weighting scheme
% Edited DEP 31 May 2020 to hard-code a ray discretizing limit

% Interval for discretizing each ray (km)
min_d = min([ domain.dx domain.dy domain.dz ]) ;
ray_int_gen = min_d/2 ; % Interval is set to half of the minimum node spacing
ray_int_max = 1 ; % Set the maximum sample interval to 1 km
if ray_int_gen < ray_int_max
    ray_int = ray_int_gen ;
else
    ray_int = ray_int_max ;
end

ray_coeffs = zeros(length(rays),domain.nmod) ;
for k = 1:length(rays)
    ray = rays{k} ;

    % Read in ray data
    rayrad = ray(:,1) ; % radius
    raylat = ray(:,2) ; % lat
    raylon = ray(:,3) ; % lon
    [ rayx,rayy ] = latlon2xy(raylat,raylon,domain.origin) ;

    % Calculate distances between each ray segment and midpoints
    raydist = distCalc(raylon(1:end-1),raylat(1:end-1),rayrad(1:end-1),raylon(2:end),raylat(2:end),rayrad(2:end)) ;

    % Discretize the ray
    if raydist(1) == 0
        dr_true = cumsum(raydist) ;
        rayx = rayx(2:end) ;
        rayy = rayy(2:end) ;
        rayrad = rayrad(2:end) ;
    else
        dr_true = cumsum([ 0 ; raydist ]) ;
    end
    dr_use = [ 0:ray_int:max(dr_true) ]' ;
    dr_use = [ dr_use ; max(dr_true) ] ;

    % Sample along discretized ray
    rx = interp1(dr_true,rayx,dr_use) ;
    ry = interp1(dr_true,rayy,dr_use) ;
    rz = interp1(dr_true,6371-rayrad,dr_use) ;

    % Approximate the midpoint of each segment with the midpoint
    %   of each component
    rx_mid = (rx(2:end)+rx(1:end-1))/2 ;
    ry_mid = (ry(2:end)+ry(1:end-1))/2 ;
    rz_mid = (rz(2:end)+rz(1:end-1))/2 ;

    % Determine the length of each segment
    dr_dist = dr_use(2:end)-dr_use(1:end-1) ;

    % Cycle through each ray segment
    ray_coeff = zeros(domain.nmod,1) ;
    for i = 1:length(dr_dist)
        % Find indices of the surrounding nodes
        n_indx = findNodes(rx_mid(i),ry_mid(i),rz_mid(i),domain) ;
        % Determine weights for each node
        wts = nodeWeights(rx_mid(i),ry_mid(i),rz_mid(i),n_indx,domain) ;
        % Determine the starting velocity at the center of the ray segment
        vij = sum(in_model(n_indx).*wts) ;
        for j = 1:length(n_indx)
           mind = n_indx(j) ;
           ray_coeff(mind) = ray_coeff(mind) + (-1*dr_dist(i)*wts(j)*in_model(mind)/(vij^2)) ;
        end
    end
    ray_coeffs(k,:) = ray_coeff' ;
end

end