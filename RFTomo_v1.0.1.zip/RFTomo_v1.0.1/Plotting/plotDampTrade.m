% plotDampTrade plots the damping tradeoff curves for variance using both
%   traditional and re-ray traced calculations of fit
%
% Written DEP 8 May 2020

%% Plot

xvar = norm_mns ;
zvar = damp_vals ;
yvar = zeros(size(zvar)) ;
dtmp = delay-d_pred(:,1) ;
k_indx = find(dtmp>(-1*cutoff)&dtmp<cutoff) ;
for ii = 1:length(zvar)
    dtmp = delay-d_preds(:,ii) ;
    if use_cutoff == true
        dtmp = dtmp(k_indx) ;
    end
    yvar(ii) = var(dtmp) ;
end

tstr = 'Damping tradeoff' ;

xoff = 0.02 ;
yoff = 0 ;

% Plot yvar
scatter(xvar,yvar,50,'black','filled') ;
title(tstr) ;
xlabel('L2 model norm (dVs/Vs)') ;
ylabel('Data misfit variance (s^2)') ;

hold on

% Plot initial fit
dtmp = delay-d_pred(:,1) ;
yvar0 = var(dtmp(k_indx)) ;
scatter([0],yvar0,50,'black')

% Plot text labels
text([0]+0.05,yvar0,'Initial','HorizontalAlignment','left')
for i = 1:length(zvar)
    text(xvar(i)+xoff,yvar(i)+yoff,num2str(zvar(i))) ;
end

legend('New predicted residuals','Initial residuals')
