% plotDataHists plots a histogram of Ps-P residuals for a velocity model
%   in relation to a residual cutoff
%
% Written DEP 8 May 2020

%% Define variables

dmin = -2 ; % minimum bin value
dmax = 2 ; % Maximum bin value
dbin = 0.1 ; % Bin increment
ymax = 20 ; % Y axis maximum for plotting

iter = 2 ; % Iteration for calculating residuals. Use 1 for initial residuals 

%% Plot
xvar = delay-d_preds(:,iter) ;
tstr = 'Ps-P residuals' ;

bins = dmin:0.1:dmax ;
histogram(xvar,bins,'FaceColor',[0.5 0.5 0.5])
title(tstr)
xlabel('Ps-P residual time (s)')
ylabel('Number of data')
ylim([0 ymax])

if use_cutoff == true
    hold on
    plot([-1*cutoff -1*cutoff],[0 ymax],'k--','LineWidth',2)
    plot([cutoff cutoff],[0 ymax],'k--','LineWidth',2)
end
