% plotSynths plots an overview of a synthetic test result as multiple W-E 
%   cross sections across the appropriate iteration
%
% Written DEP 16 May 2020

%% Define variables

% Load appropriate tomography workspace
load('../Saved/synth_sample.mat') ;

% Load input model
synth = load('../Saved/SynthModels/ex1_sample.mat') ;

% Set map limits in km
h_bounds = [ -50 50 ] ;
v_bounds = [ domain.zmin domain.zmax ] ;

% Upsampling distances
msamp = 0.25 ; % Sampling distance for Moho
nsamp = 0.25 ; % Sampling distance for par in x, y, and z

% Choose cross section (y distance in km)
ycrosses = [ -20 -10 0 10 20 ] ;

% choose which iterations to plot - last value should be chosen iteration
iter = 2 ;

% Set color axis limits
vcmin = 2.2 ; vcmax = 5.2 ; % Axis limits for velocity plots, in km/s
rcmin = 0.0 ; rcmax = 0.5 ; % Axis limits for R diagonal plots

%% Plot

% Create sample grid
hvals = [ h_bounds(1):nsamp:h_bounds(2) ] ;
vvals = [ v_bounds(1):nsamp:v_bounds(2) ] ;
[ hgrd, vgrd ] = meshgrid(hvals,vvals) ;

for k = 1:length(ycrosses)
    ycross = ycrosses(k) ;
    subplot(3,length(ycrosses),k)
    l = iter ;
    
    % Plot input
    par = synth.synth_model(:,2) ;
    par_plot_i = zeros(size(hgrd)) ;
    for jjj = 1:length(hvals)
        for iii = 1:length(vvals)
            n_indx = findNodes(hgrd(iii,jjj),ycross,vgrd(iii,jjj),synth.domain) ;
            wts = nodeWeights(hgrd(iii,jjj),ycross,vgrd(iii,jjj),n_indx,synth.domain) ;
            vij = sum(par(n_indx).*wts) ;
            par_plot_i(iii,jjj) = vij ;
        end
    end
    indxi = find(synth.domain.my == ycross & synth.domain.mx>=h_bounds(1) & synth.domain.mx<=h_bounds(2)) ;
    h = synth.domain.mx(indxi) ; nh = length(unique(h)) ;
    v = synth.domain.mz(indxi) ; nv = length(unique(v)) ;
    par2i = par(indxi) ;
    colormap(flipud(jet)) ;
    image(h_bounds,v_bounds,par_plot_i,'CDataMapping','scaled')
    hold on
    scatter(h,v,10,'k','filled') ;
    set(gca,'YDir','reverse') 
    caxis([vcmin vcmax]) ;
    title(sprintf('Y = %02d km, Input',ycross))  ;
    xlabel('X distance (km)') ;
    ylabel('Depth (km)') ;
    c = colorbar;
    c.Label.String = 'Absolute Vs (km/s)';
    daspect([1 1 1])
    hold on
    
    if ismember(ycross,synth.domain.mody)
        % Plot Moho
        indx2i = find(synth.Moho.y == ycross & synth.Moho.x>=h_bounds(1) & synth.Moho.x<=h_bounds(2)) ;
        [ xplot, m_indx ] = sort(synth.Moho.x(indx2i)) ;
        mplot_tmp = synth.Moho.depth(indx2i) ;
        mplot = mplot_tmp(m_indx) ;
        xplot_int = min(xplot):msamp:max(xplot) ;
        mplot_int = interp1(xplot,mplot,xplot_int,'pchip') ;
        plot(xplot_int,mplot_int,'k','LineWidth',2)
    
        % Plot Elevation
        eplot_tmp = synth.Moho.elevs(indx2i) ;
        eplot = eplot_tmp(m_indx) ;
        eplot_int = interp1(xplot,eplot,xplot_int,'pchip') ;
        plot(xplot_int,-1*eplot_int,'k','LineWidth',2)
    end
    
    % Plot output
    subplot(3,length(ycrosses),k+length(ycrosses))
    par = vms(:,l) ;
    par_plot = zeros(size(hgrd)) ;
    for jjj = 1:length(hvals)
        for iii = 1:length(vvals)
            n_indx = findNodes(hgrd(iii,jjj),ycross,vgrd(iii,jjj),domain) ;
            wts = nodeWeights(hgrd(iii,jjj),ycross,vgrd(iii,jjj),n_indx,domain) ;
            vij = sum(par(n_indx).*wts) ;
            par_plot(iii,jjj) = vij ;
        end
    end
    indx = find(domain.my == ycross & domain.mx>=h_bounds(1) & domain.mx<=h_bounds(2)) ;
    h = domain.mx(indx) ; nh = length(unique(h)) ;
    v = domain.mz(indx) ; nv = length(unique(v)) ;
    par2 = par(indx) ;
    colormap(flipud(jet)) ;
    image(h_bounds,v_bounds,par_plot,'CDataMapping','scaled')
    hold on
    scatter(h,v,10,'k','filled') ;
    set(gca,'YDir','reverse') 
    caxis([vcmin vcmax]) ;
    title(sprintf('Y = %02d km, iter = %01d',ycross,l))  ;
    xlabel('X distance (km)') ;
    ylabel('Depth (km)') ;
    c = colorbar;
    c.Label.String = 'Absolute Vs (km/s)';
    daspect([1 1 1])
    hold on
    
    if ismember(ycross,domain.mody)
        % Plot Moho
        indx2 = find(Moho.y == ycross & Moho.x>=h_bounds(1) & Moho.x<=h_bounds(2)) ;
        [ xplot, m_indx ] = sort(Moho.x(indx2)) ;
        mplot_tmp = Moho.depth(indx2) ;
        mplot = mplot_tmp(m_indx) ;
        xplot_int = min(xplot):msamp:max(xplot) ;
        mplot_int = interp1(xplot,mplot,xplot_int,'pchip') ;
        plot(xplot_int,mplot_int,'k','LineWidth',2)
    
        % Plot Elevation
        eplot_tmp = Moho.elevs(indx2) ;
        eplot = eplot_tmp(m_indx) ;
        eplot_int = interp1(xplot,eplot,xplot_int,'pchip') ;
        plot(xplot_int,-1*eplot_int,'k','LineWidth',2)
    end
    
    % Plot R
    subplot(3,length(ycrosses),k+2*length(ycrosses))
    par = Rdiags(:,l) ;
    par_plot = zeros(size(hgrd)) ;
    for jjj = 1:length(hvals)
        for iii = 1:length(vvals)
            n_indx = findNodes(hgrd(iii,jjj),ycross,vgrd(iii,jjj),domain) ;
            wts = nodeWeights(hgrd(iii,jjj),ycross,vgrd(iii,jjj),n_indx,domain) ;
            vij = sum(par(n_indx).*wts) ;
            par_plot(iii,jjj) = vij ;
        end
    end
    par2 = par(indx) ;
    colormap(flipud(jet)) ;
    image(h_bounds,v_bounds,par_plot,'CDataMapping','scaled')
    hold on
    scatter(h,v,10,'k','filled') ;
    set(gca,'YDir','reverse') 
    caxis([rcmin rcmax]) ;
    title(sprintf('Y = %02d km, iter = %01d',ycross,l))  ;
    xlabel('X distance (km)') ;
    ylabel('Depth (km)') ;
    c = colorbar;
    c.Label.String = 'R diagonal';
    daspect([1 1 1])
    hold on
    
    if ismember(ycross,domain.mody)
        % Plot Moho
        plot(xplot_int,mplot_int,'k','LineWidth',2)
      
        % Plot Elevation
        plot(xplot_int,-1*eplot_int,'k','LineWidth',2)
    end
end

set(gcf, 'Position',  [100, 100, 400*length(ycrosses), 900])