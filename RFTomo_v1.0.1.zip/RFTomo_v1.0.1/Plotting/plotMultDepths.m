% plotMultDepths plots multiple depth slices from a single tomographic
%   iteration in one plot
%
% Written DEP 21 May 2020

%% Define variables
% Set map limits in km
x_bounds = [ -50 50 ] ;
y_bounds = [ -50 50 ] ;

% choose which iteration to plot
iter = 2 ;

% Upsampling distances
nsamp = 0.25 ; % Sampling distance for par in x, y, and z

% Choose cross sections to plot (y distance in km)
zdeps = [ 0 10 20 30 40 ] ; % Must correspond to z nodes in domain.modz

% Set color axis limits
vcmin = 2.2 ; vcmax = 5.2 ; % Axis limits for velocity plots, in km/s
rcmin = 0.0 ; rcmax = 0.5 ; % Axis limits for R diagonal plots

%% Set up plot

% Create sample grid
xvals = [ x_bounds(1):nsamp:x_bounds(2) ] ;
yvals = [ y_bounds(1):nsamp:y_bounds(2) ] ;
[ xgrd, ygrd ] = meshgrid(xvals,yvals) ;

for k = 1:length(zdeps)
    zdep = zdeps(k) ;
    subplot(2,length(zdeps),k)
    l = iter ;
    par = vms(:,l) ;
    par_plot = zeros(size(xgrd)) ;
    for iii = 1:length(xvals)
        for jjj = 1:length(yvals)
            n_indx = findNodes(xgrd(iii,jjj),ygrd(iii,jjj),zdep,domain) ;
            wts = nodeWeights(xgrd(iii,jjj),ygrd(iii,jjj),zdep,n_indx,domain) ;
            vij = sum(par(n_indx).*wts) ;
            par_plot(iii,jjj) = vij ;
        end
    end
    indx = find(domain.mz == zdep & ...
        domain.mx>=x_bounds(1) & domain.mx<=x_bounds(2) & ...
        domain.my>=y_bounds(1) & domain.my<=y_bounds(2)) ;
    x = domain.mx(indx) ; nx = length(unique(x)) ;
    y = domain.my(indx) ; ny = length(unique(y)) ;
    colormap(flipud(jet)) ;
    image(x_bounds,y_bounds,par_plot,'CDataMapping','scaled')
    hold on
    scatter(x,y,10,'k','filled') ;
    set(gca,'YDir','normal') 
    caxis([vcmin vcmax]) ;
    title(sprintf('Z = %02d km, iter = %01d',zdep,l))  ;
    xlabel('X distance (km)') ;
    ylabel('Y distance (km)') ;
    c = colorbar;
    c.Label.String = 'Absolute Vs (km/s)';
    daspect([1 1 1])
    scatter(stax,stay,30,'k','filled','v') ;
    
    subplot(2,length(zdeps),k+length(zdeps))
    par = Rdiags(:,l) ;
    par_plot = zeros(size(xgrd)) ;
    for iii = 1:length(xvals)
        for jjj = 1:length(yvals)
            n_indx = findNodes(xgrd(iii,jjj),ygrd(iii,jjj),zdep,domain) ;
            wts = nodeWeights(xgrd(iii,jjj),ygrd(iii,jjj),zdep,n_indx,domain) ;
            vij = sum(par(n_indx).*wts) ;
            par_plot(iii,jjj) = vij ;
        end
    end
    colormap(flipud(jet)) ;
    image(x_bounds,y_bounds,par_plot,'CDataMapping','scaled')
    hold on
    scatter(x,y,10,'k','filled') ;
    set(gca,'YDir','normal') 
    caxis([rcmin rcmax]) ;
    title(sprintf('Z = %02d km, iter = %01d',zdep,l))  ;
    xlabel('X distance (km)') ;
    ylabel('Y distance (km)') ;
    c = colorbar;
    c.Label.String = 'R diagonal';
    daspect([1 1 1])
    scatter(stax,stay,30,'k','filled','v') ;
end
set(gcf, 'Position',  [100, 100, 400*length(zdeps), 600])