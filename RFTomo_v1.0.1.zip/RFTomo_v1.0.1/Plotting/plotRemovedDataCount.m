% plotRemovedDataCount plots the number of removed data for each iteration
%   of in inversion given the assigned cutoff residual value
%
% Written DEP 8 May 2020

%% Plot

xvar = norm_mns(1:end-1) ;
xvar = [ 0 ; xvar ] ;
zvar = 0:n_iter ;

for ii = 1:(n_iter)
    yvar(ii) = length(d_rems{ii}) ;
end

tstr = 'Data removed' ;

xoff = 0.1 ;
yoff = 0 ;

% Plot yvar1
scatter(xvar,yvar,50,'black','filled') ;
title(tstr) 
xlabel('L2 model norm (dVs/Vs)') ;
ylabel('Number of data') ;
hold on

% Plot text labels
for i = 1:length(xvar)
    text(xvar(i)+xoff,yvar(i)+yoff,num2str(zvar(i))) ;
end
yl = ylim ;
ylim([0 yl(2)])