function [ domain ] = setupDomain(data,origin,zrange,dx,dy,dz,padxy)

% Sets up a regularly spaced model domain based on input 
% station array
%
%
% After SetupTomoGeom from B. Schmandt
%
% Written DEP 22 Feb 2020
% Edited DEP 8 Apr 2020 to make sure position 0 is origin
% Edited DEP 6 May 2020 to make node spacing and padding input variables
% Edited DEP 7 May 2020 to include a boundary node at 3X node spacing
% Edited DEP 10 May 2020 to make sure Z=0 is a node

% Identify min/max for lateral grids
xmin = (round((min(data.ray.stax) - padxy)/dx))*dx ;
ymin = (round((min(data.ray.stay) - padxy)/dy))*dy ;
zmin = round(zrange(1)/dz)*dz ;
xmax = (round((max(data.ray.stax) + padxy)/dx))*dx ;
ymax = (round((max(data.ray.stay) + padxy)/dy))*dy ;
zmax = round(zrange(2)/dz)*dz ;

% Identify node locations in xyz
%   If range is not a multiple of node spacing, range will be shortened
modx = [ xmin:dx:xmax ] ;
mody = [ ymin:dy:ymax ] ;
modz = [ zmin:dz:zmax ] ;

% Add one large node on every side at 3 times the spacing
modx = [ modx(1)-(3*dx) modx modx(end)+(3*dx) ] ;
mody = [ mody(1)-(3*dy) mody mody(end)+(3*dx) ] ;

nx = length(modx) ; ny = length(mody) ; nz = length(modz) ;

nmodel = nx*ny*nz ;
dmodx = dx*ones(size(modx)) ;
dmody = dy*ones(size(mody)) ;
dmodz = dz*ones(size(modz)) ;

mx = zeros(nmodel,1) ;
my = zeros(nmodel,1) ;
mz = zeros(nmodel,1) ;
mlat = zeros(nmodel,1) ;
mlon = zeros(nmodel,1) ;

% Create grid, varying longitude, then latitude, then depth
n=1 ;
for k = 1:nz
    for j = 1:nx
        for i = 1:ny
            mx(n) = modx(j) ;
            my(n) = mody(i) ;
            mz(n) = modz(k) ;
            n = n+1 ;
        end
    end
end
clear n
q = 1:nmodel ;
[ mlat(q),mlon(q) ] = xy2latlon(mx(q),my(q),origin) ;

% Save model to domain structure
domain.dx = dx ; domain.dy = dy ; domain.dz = dz ;
domain.xmin = min(modx) ; domain.xmax = max(modx) ;
domain.ymin = min(mody) ; domain.ymax = max(mody) ;
domain.zmin = min(modz) ; domain.zmax = max(modz) ;
domain.nx = nx ; domain.ny = ny ; domain.nz = nz ;
domain.mx = mx ; domain.my = my ; domain.mz = mz ;
domain.mlat = mlat ; domain.mlon = mlon ;
domain.modx = modx ; domain.mody = mody ; domain.modz = modz ;
domain.origin = origin ;

domain.nmod = nmodel ;
domain.mind = [ 1:domain.nmod ]' ;

end