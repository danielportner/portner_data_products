### RFTomo ###
User guide

A guide to using RFTomo, a software for using Moho-generated Ps-P delay times 
determined using receiver function analysis in a local tomographic inversion.

Contact: For any questions about usage or to report any problems, please 
contact me (Daniel Evan Portner) at the current email address provided on my 
personal webpage, www.danielportner.com.

----------
Version 1.0.1
3 October 2024
Daniel Evan Portner

Citation: Portner, D.E., Delph, J.R., Kiser, E., Abers, G.A., Levander, A., and 
Pang, G. Validation of Ps-P Tomography for Obtaining 3D Crustal Vp/Vs With Small-N 
Data Sets: An Application to the Mount St. Helens Magmatic System. Journal of 
Geophysical Research: Solid Earth, 129, doi:10.1029/2024JB029642.

Citation: Portner, D.E., Wagner, L.S., Janiszewski, H.A., Roman, D.C., and
Power, J.A. Ps-P Tomography of a Midcrustal Magma Reservoir Beneath Cleveland
Volcano, Alaska. Geophysical Research Letters, 47, doi:10.1029/2020GL090406.

Compatibility: This code has been tested using MATLAB R2024a and performed and
tested on macOS Ventura Version 13.5 with an Apple M2 chip. It is not a 
complicated code and I do not imagine it will run into issues with MATLAB updates, 
but be aware that it is not tested beyond my own setup. Non-unix platforms may run 
into issues at the portions of code that perform command-line calls (lines using 
command "unix"). However, I imagine these issues will require only minor syntax 
changes to function.

Use: This code is free and available for anyone to use for their own purposes.
All I ask is that users properly cite the technique (citation above) and are
aware of the contributions from other authors and researchers, as noted in the
cited paper and within the code itself. That being said, feel free to contact me
about potential applications, collaborations, and/or adaptations as you see fit.
I am always open to new uses and ideas!

INTRODUCTION
There are very few updates to the guide here because there are very few updates to 
the RFTomo code compared to Version 1.0.0. In fact, there are no technical updates 
that need to be described here. This new version exists mainly to provide data that 
can be used to reproduce the models in our new publication on Mount St. Helens. For 
a complete description of the code and an explanation of how to use it, see the 
guide from Version 1.0.0 (copied below). Here, we just include a few comments on the 
differences between this release and the prior release.

UPDATES
1. The Library and InputFiles contain slightly different files. Those included here 
(ex. Library/sampleMoho_msh.txt, InputFiles/sampleInput_imush.dat) are needed to 
reproduce the published MSH1_S_2023 tomography model.

2. makeSynthChecker.m is a new tool that designs a checkerboard synthetic velocity 
structure for synthetic tests. Checkerboards were used to evaluate the new model 
because the domain was broad enough for this to be practical, unlike in the Cleveland 
study.

3. The default velocity model in getvel1D.m and the default Moho model in getMoho.m 
are different to reflect the improved a priori information at Mount St. Helens. This 
includes the ability to upload a Moho geometry, rather than just create a simple 
geometric Moho. 

4. An error was fixed in the cross section plotting scripts in Plotting (e.g. 
plotMultCrosses.m). 

5. There are no saved workspaces in this release because the files are too big to 
share. However, some sample figures are included that should be able to be reproduced 
by running the code with default parameters.

That's it! If you notice any differences I missed that need to be explained, or have 
any questions, feel free to reach out and let me know.

END 

----------
Version 1.0.0
29 January 2020
Daniel Evan Portner

Citation: Portner, D.E., Wagner, L.S., Janiszewski, H.A., Roman, D.C., and 
Power, J.A. Ps-P Tomography of a Midcrustal Magma Reservoir Beneath Cleveland 
Volcano, Alaska. Geophysical Research Letters, 47, doi:10.1029/2020GL090406.

Compatibility: This code was written using MATLAB R2019b and performed and 
tested on macOS Mojave Version 10.14.6. It is not a complicated code and I do 
not imagine it will run into issues with MATLAB updates, but be aware that it 
is not tested beyond my own setup. Non-unix platforms may run into issues at the 
portions of code that perform command-line calls (lines using command "unix"). 
However, I imagine these issues will require only minor syntax changes to function.

Use: This code is free and available for anyone to use for their own purposes. 
All I ask is that users properly cite the technique (citation above) and are 
aware of the contributions from other authors and researchers, as noted in the 
cited paper and within the code itself. That being said, feel free to contact me 
about potential applications, collaborations, and/or adaptations as you see fit. 
I am always open to new uses and ideas!

INTRODUCTION
This guide is designed to walk you through set up and usage of the code. I will 
use the data and models used in the citation above as an example but will note 
where changes should be made for your own purposes. Some "relatively" generic 
visualization scripts are provided and sample figures using my own model runs 
will be provided for comparison. What this guide will not include is a detailed 
explanation of the theoretical basis for the technique or explanations for 
practical concessions made in the code. For these details, please visit the 
relevant publication (citation above) and references therein.
	The RFTomo technique, also called Ps-P crustal tomography, is designed 
to use the information contained in converted phase delay times to image the 3D 
velocity structure of the crust. In this case, we use converted phases 
generated at the Moho, which allows for imaging of the entire crust (though 
theoretically, converted phases generated at any continuous boundary with clear 
converted phases can be used, assuming boundary structure is known a priori). 
Converted phase delay times are dependent on both P and S wave velocity 
structures, as well as converter geometry, so some assumptions need to be made. 
In this iteration of RFTomo, we assume that the P wave velocity structure and 
the Moho geometry are known so that we can isolate the variations in Vp/Vs 
structure (proxied by variations in Vs). The key procedure in this technique is 
that though we assume the crustal portion of the Ps path as our ray path, 
predicted delay times and predicted ray paths are determined by ray tracing 
from the teleseismic source to the station while accounting for phase 
conversion. This means that the direct P travel time and travel path are 
calculated through a global reference P wave model and our local starting model 
and the Ps converted phase travel time and travel path are calculated using a 
global reference P wave model and the local crustal S wave model. An important 
result of this procedure is that Moho pierce points, or the local S wave 
source, is not assumed using the reference model, but is iteratively updated to 
account for local hetergeneity. The result of this technique, in this version, 
is a 3D model of relative S wave velocity perturbations in the crust. However, 
as noted previously, because P wave velocity is fixed a priori, the model is 
really a proxy for relative variations in Vp/Vs in the crust. Notably, the 
model provides no constraint on absolute velocities because of the tradeoff 
between crustal velocities and layer thickness.

GETTING STARTED - INSTALLATION
This code consists of two components: RFTomo and fmtomo. RFTomo is run in 
MATLAB, but relies upon fmtomo for ray tracing and travel time predictions. 
Therefore, fmtomo MUST be installed prior to using RFTomo.

Step 1: Install fmtomo (de Kool, et al., 2006; Rawlinson, et al., 2006)

de Kool, M., Rawlinson, N., & Sambridge, M. (2006). A practical grid‐based 
method for tracking multiple refraction and reflection phases in 
three‐dimensional heterogeneous media. Geophysical Journal International, 
167(1), 253–270. https://doi.org/10.1111/j.1365‐ 246X.2006.03078.x.

Rawlinson, N., de Kool, M., & Sambridge, M. (2006). Seismic wavefront tracking 
in 3D heterogeneous media: Applications with multiple data classes. Exploration 
Geophysics, 37(4), 322–330. https://doi.org/10.1071/EG06322.

fmtomo is a fortran tomography package from the references above. The most 
recent version can be downloaded here: http://rses.anu.edu.au/~nick/fmtomo.html
Download the code and follow the instructions therein for installation. Make 
sure the path to the fm3d run script is known. It will need to be hard-coded into 
script "fwdCalc.m".

**Note**
Depending on the version of fmtomo downloaded, a small adaptation may need to 
be made. Some versions of fm3d output the Z component of ray paths in terms of 
radius, but this will need to be adjusted to print in terms of depth.

Step 2: Run in MATLAB
Once fm3d is properly installed, the rest of the code is operated in MATLAB.

PRACTICE RUN

**Important**
Once fmtomo is installed, you should only need to make one change before 
running RFTomo. Before running anything, open "fwdCalc.m" and change the 
variable "fm3d_path" to the relevant path to the fm3d executable.

Step 0: Input files
Only one input data file is required and must be defined as variable 
"delayFile" in the run script ("run_rftomo.m"). The sample input file for the 
test case is called "sampleInput_cleveland.dat" and is located in directory 
"InputFiles". The input file is structured as an ASCII file with each row 
representing an individual event-station pair. The file should be organized in 
columns as follows:
[ evid evlat evlon evdep staname stalat stalon stael phase dt ]

evid - A unique ID number for each individual event. For events that yield 
	multiple data, it helps to give them the same ID so that travel time 
	predictions can be made in unison. However, the code will work fine 
	(just slowly, so not recommended) if each datum has its own evid.
evlat - Latitude of the event.
evlon - Longitude of the event.
evdep - Depth of the event (in km)
staname - Unique station name. I include the network code, but this is not 
	required.
stalat - Latitude of the station.
stalon - Longitude of the station.
stael - Elevation of the station (in m).
phase - Direct teleseismic phase for the given delay time. I have only used "P" 	and "PP", so these are the only ones I know will work. Other phases 
	should work if they are included in the fmtomo phase catalog.
dt - Ps-P delay time. This is where the delay time between the direct phase and 
	converted phase goes. All of phases should be converted from the same 
	boundary.

There are also several "Library" files that need to be provided for specific 
locations. These include universal files called "ak135.hed", "ak135.tbl", 
"ak135.tvel", "frechet.in", and "mode_set.in", and a replaceable file topography 
file (the included example is "ETOPO1_Bed_g_gmt4_cut_Cleveland.xyz". The 
universal files are all needed for running the fm3d ray tracing code and are 
explicitly copied to the appropriate directory from the Library within the code. 
This is to ensure that if they are accidentally deleted or altered, a backup is 
included (they are never written within the code). The topography file is a 
three column ASCII file of the format [longitude latitude elevation] where 
elevation is in meters above sea level. This file is cut to a smaller size 
surrounding the study area and may be replaced by similar files in another 
relevant study area. If the topography file is replaced, change the call to the 
file through variable "topoFile" in "getMoho.m". The ETOPO topography grid can be 
downloaded from www.ngdc.noaa.gov/mgg/global/ and downsampled, cut, and/or 
converted to ASCII format using GMT (https://www.generic-mapping-tools.org/). 
Alternatively, higher resolution topography grids can be found at www.gmrt.org/ 
if needed.

Step 1: Define variables
"run_rftomo.m" is designed as a call script that calls the tomography script 
"rftomo_v1_0_0.m". All basic variables that might need to be changed for a 
single tomography run are defined explicitly in "run_rftomo.m". Other variables 
that can be changed will be noted later. These main variables are as follows:

delayFile - The input file described above.
n_iter - The number of iterations to be run. This can be slightly higher than 
	the optimal number of iterations, as all intermediate models will be 
	saved.
use_cutoff - This is "true" or "false" and determines whether or not you want 
	to automatically discard residuals above/below a certain threshold. 
	These residuals will be gradually added back into the inversion if the 
	residuals are reduced below the threshold.
cutoff - If "use_cutoff" is "true", this is the residual threshold above which 
	(and below the negative of which) all residuals will be excluded from 
	the inversion. This should always be positive.
damp - A pre-defined damping parameter equivalent to epsilon^2 in the damped 
	least squares inverse operator.
origin - This is a couplet that sets the location defined as [0 0] in the 
	Cartesian reference frame. The format is [ latitude longitude ].
dx, dy, dz - Node spacing in the x (east/west), y (north/south), and z (depth) 
	directions in km. In this version, node spacing is uniform throughout 
	the model in a single direction, though dx, dy, and dz can be different 
	from eachother.
pad - This defines the lateral width of a single node bounding the edge of the 
	model domain in km. This should be wide enough to ensure that all rays 
	enter from the bottom of the model. Thus, it will need to be bigger for
	deeper converters and can be smaller for shallower converters. This is 
	defined separately from the rest of the model domain in order to allow 
	the edges to be more sparsely sampled, reducing the model size where 
	ray coverage is sparsest.
zrange - Defines the vertical bounds of the model in the format [ top bottom ], 	where negative numbers are in km above sea level and positive are km 
	below sea level. Nodes are assigned top down, so adjust these in 
	conjunction with "dz" to ensure nodes are at the appropriate depths. 
	These should be defined such that "top" is above the highest elevation 
	station and "bottom" is deeper than the entire converter.
vmod - Identifies which velocity model to use, selected from a database defined 
	in "getvel1D.m". The two "pre-loaded" models are an adapted AK135 
	(vmod = 1) and a model with a uniform crustal P wave velocity of 6.5 
	km/s and a user-defined uniform crustal S wave velocity (vmod = 2). 
	These models can be adjusted and new models can be added in 
	"getvel1D.m".
vs_crust - If using vmod = 2, this defines the crustal S wave velocity in km/s.
moho_type - Identifies the style of Moho to be used. "Pre-loaded" options 
	include a flat Moho at depth defined by "smoho" (moho_type = 1), a 
	pseudo-isostatically compensated Moho (moho_type = 2), and a Moho that 
	is flat except for a single Moho node that is variable at the origin 
	(moho_type = 3). These Moho definitions can be found in "getMoho.m", 
	where additional Moho types may also be defined independently.
	For moho_type = 2, isostasy is determined with "smoho" defining a 
	compensated Moho depth where elevation is at sea level. Densities are 
	defined in "getMoho.m" and can be changed. Isostatic compensation does 
	not account for ocean water.
smoho - This defines the Moho depth (in km below sea level) in different ways 
	depending on which "moho_type" is used. For moho_type = 1 and 
	moho_type = 3, "smoho" defines the "flat" part of the Moho. Its 
	definition for moho_type = 2 is noted above.
mcent - This is exclusively for moho_type = 3, and defines the Moho depth (in 
	km below sea level) at the origin, allowing that Moho value to be 
	distinct from the rest of the Moho values. This is designed 
	specifically for the Cleveland case study, though may be useful in 
	other scenarios where a crustal root may be hypothesized at the origin 
	of the model domain.

Step 2: Run tomography
Running "run_rftomo" will call the main tomography script, "rftomo_v1_0_0", 
using the above-defined variables. If allowed to run to completion, it will 
also save the entire workspace in a ".mat" file named "tmp.mat", just in case 
you accidentally close MATLAB before saving.

Step 3: Plotting
Some quick generic plotting scripts are contained in the "Plotting" directory. 
Within that directory, subdirectory "SampleFigures" contains figures from the 
included example dataset. Ensure that the appropriate workspace (ie. "tmp.mat") 
is loaded prior to running any of the plotting scripts. If the code and 
plotting scripts are run without adaptation using the default variables and 
datasets, the included plotting scripts should match exactly with the sample 
figures. Also note that most of the plotting scripts use functions in the main 
directory, so you will want to add the main directory to your path. This is done 
automatically when running the code (in "fwdCalc.m"), but if plotting after newly 
opening MATLAB, run "addpath(pwd)" from the main directory before trying the plot 
scripts.

1. To get a quick view of the resulting S wave tomography model, run 
	"plotMultDepths.m" and "plotMultCrosses.m". These plot a select number 
	of depth slices or W-E cross sections through the model, along with the 	diagonal values of the R resolution matrix for the selected iteration. 
	Before running, verify that the variables in the "Define variables" 
	section are appropriate. See figures "multDepths_iter3.png" and 
	"multCrosses_iter3.png" for an example.
2. To get a sense for how the model changes through each iteration, run
	"plotIterCrosses.m". This will plot a single cross section across 
	select iterations using the same style as "plotMultCrosses.m". Again,
	verify the variables in the "Define variables" section. See figure 
	"iterCrosses_y00.png" for an example.
3. To get a quick look at data fit with respect to a velocity model, use
	"plotDataHist.m". Verify variables in the "Define variables" section. 
	Set "iter" to 1 to view the initial data fit. See figures 
	"dataHist_iter?.png" for examples of residuals with respect to the 
	starting model and with respect to the final model.
4. To get a quantitative sense of the tradeoff between data fit and model size 
	across iterations, use "plotIterTrade.m" and "plotRemovedDataCount.m". 
	These the tradeoffs between model size and data fit and number of data 
	exceeding the chosen residual threshold. Each dot is labeled with the 
	iteration, with 0 representing fit to the starting model of size 0. 
	Do not use the latter script unless a cutoff value is used. See 
	figures "iterTrade.png" and "removedData.png" for examples.

OTHER SCRIPTS

Damping tradeoff analysis
An important step in the tomography procedure is to choose the appropriate 
damping parameter to use. The damping parameter is selected using analysis 
of the tradeoff between data fit and model size for a range of damping values. 
Use "dampTradeoff.m" to perform damping tradeoff analysis. This script was 
included to facilitate this process. This script works by first preparing a 
generic inversion by calculating initial model predicted ray paths and travel 
time residuals and then saving this information. This information is then used 
to run a series of inversions for one iteration with different damping 
parameters. After the first iteration of each inversion, the resulting velocity 
model is used to predict new travel time residuals that are used to evaluate 
data fit. This script consists of a reordering of much of the code in 
"rftomo_v1_0_0.m" and so both should be considered when making changes to one.
	To use "dampTradeoff.m", first ensure that the values in the "Define 
parameters" section are appropriate. See the above section on "run_rftomo.m" 
for details. The only difference here is that instead of assigning a damping 
value, a vector of damping values is included as "damp_vals". The example 
provided only includes a limited number of tested damping parameters, but it 
may be appropriate to test a much wider range. This script will again save the 
resulting workspace to "tmp.mat". Be sure not to overwrite a prior version. A 
sample workspace is included in the "Saved" directory, called 
"tradeoff_sample.mat".
	The tradeoff curve resulting from this test can be plotted using 
"plotDampTrade.m" in the "Plotting" directory. See figure "dampTrade.png" for 
the example tradeoff curve.

Synthetic testing
Synthetic anomaly recovery tests are a critical aspect of evaluating how to 
interpret any tomography model. The way this works is that a synthetic velocity 
model is generated and predicted travel times are generated through it using 
the same ray configuration as the input data. Those travel times are then 
treated as observed data using the a priori (rather than the known) starting 
velocity model and the inversion proceeds in an equivalent manner as the true 
tomographic inversion. Several scripts are included to facilitate this process. 
	The first of these is "makeSynthModel.m". This gives an example of how 
to generate a synthetic velocity model. To run "makeSynthModel.m", first ensure 
that a tomography workspace (such as "tmp.mat") is loaded into memory. Then the 
script can be run as-is. "makeSynthModel.m" generates a synthetic model 
variable aptly named "synth_model". 
	When a synthetic model is created (using "makeSynthModel.m" or by other 
means), run "getSynthInput.m". What this script does is it creates an input 
data file with precicted delay times through the synthetic model. A sample, 
named "sampleInput_synthetic.dat" is included in the "InputFiles" directory. 
Notice that it shares a file format with the input data file 
"sampleInput_cleveland.dat". To run this script, first ensure that a tomography 
workspace is loaded into memory, as is the variable "synth_model". Then edit 
variable "outfile" to name the desired file name and destination for the 
synthetic data. After running (or before) it is important to save "synth_model" 
to file after creating it. I usually save it after so that I can also save the 
predicted travel times in the synthetic model file. An example is included in 
the "SynthModels" subdirectory in "Saved" as "ex1_sample.mat".
	Finally, when a synthetic dataset is generated, simply change the input 
file name (variable "delayFile") in "run_rftomo.m" and run that script. This 
will perform the synthetic anomaly recovery test. The example run of this is 
saved as "synth_sample.mat".
	To evaluate the synthetic results, use plotting script "plotSynths.m". 
To use this script, first verify the variables in the "Define variables" 
section. **Note** These include loading the saved workspaces into memory so the 
input model may also be plotted. Load to memory the workspace
(ie. "synth_sample.mat") and load to to variable "synth" the synthetic model 
(ie. "ex1_sample.mat"). A sample figure is included as "synthModel_iter3.png".

CODE WALK-THROUGH

This section begins when the "run_rftomo.m" run script reaches "rftomo_v1_0_0". 
At this point, the main tomography code script, "rftomo_v1_0_0.m" is called. 

readData.m
The first thing to occur at this point is that the data from our input file 
("delayFile") defined in the call script is loaded into structure "data" using 
"readData.m". "readData" separates the columns of the input file into individual 
variables, while also separating data into unique station ("sta") and event 
("evt") structures. Each input datum (a unique line in "ray") has a variable to 
denote which event and which station is associated. Key to this process is that 
events are defined by a unique location AND a unique phase. Delay times relative 
to the direct P phase are assessed separately from delay times relative to the PP 
phase.

latlon2xy.m
Next is some quick book keeping in which station locations in latitude/longitude are 
converted to locations in x/y in units of kilometers east and north of the origin 
location assigned in the call script. This is done using script "latlon2xy.m". It is 
performed along the surface of a circle with radius 6371 km. A similar script, 
"xy2latlon.m" performs the reverse conversion from x/y to lat/lon. This same 
conversion is performed at all depths, meaning that the sphericity of Earth is not 
accounted for. This is not a problem for shallow tomography models, but if using 
deeper discontinuities, such as the 410 km discontinuity, be aware that adaptations 
may be appropriate.

setupDomain.m
The model domain is defined using the script "setupDomain.m". This script defines a 
model domain that extends at least to the furthest station in each direction from 
the origin with nodes separated by "dx" and "dy" as defined in the call script. An 
additional node three times the size of "dx" and "dy", respectively, is added to each 
side to account for extra nodes needed in the ray tracing steps. In this version, 
node spacing is uniform along a given axis and is identical across depth layers. The 
model domain created here is saved to a universal structure "domain" which is used 
throughout the rest of the code. 

getMoho.m
"getMoho.m" defines both the topography and Moho along the same grid as defined by 
the node distribution in the "domain" structure. Topography is extracted at the 
relevenat lat/lon locations by interpolation from a topography file defined by 
variable "topoFile" in "getMoho.m". I keep this file in the "Library" directory, as 
noted. Topography is only used for generation of the pseudo-isostatic Moho and for 
plotting purposes and otherwise is not needed for function of the code. Moho is 
created based on variables "moho_type", "smoho", and "mcent" defined in the call 
script and is saved into structure variable "Moho". Currently, three Moho "types" 
are accomodated (flat, pseudo-isostatic, and one-node root), but others can easily 
be added to this file. If Moho geometry is known a priori, add a fourth type and 
define it explicitly using that information (similarly to how topography is defined). 
Note that for the "pseudo-isostatic" Moho type, water is ignored and 
densities are defined in the script as "p_oc" and "p_ml" for the crust and mantle, 
respectively. These can be changed to accommodate regional information. Flexure is 
not accounted for. In this case, "smoho" defines the crustal thickness associated 
with elevation = sea level.

getStartModel.m
After the Moho is defined, a started model can be defined using "getStartModel.m". A 
defined Moho is necessary because included starting models have a velocity jump 
defined by the Moho depth. This script works by interpolating the chosen velocity 
model (variable "vmod" in the call script) in 1D individually at each grid node of 
the defined "domain". The resulting velocity model is defined only at the model 
domain nodes and is saved to variable "smodel", which includes both a P wave and S 
wave model. The first column of the variable is always the P wave model and the 
second is always the S wave model. Interpolation is performed using "interpvel1D.m".

interpvel1D.m
"interpvel1D.m" simply extracts a pre-defined velocity model from "getvel1D.m" and 
linearly interpolates it at the depths defined in the velocity model. This is done 
for both P wave and S wave velocities.

getvel1D.m
"getvel1D.m" is essentially just a library of velocity models that can be called by 
"interpvel1D.m", as assigned by variable "vmod" in the call script. Each velocity 
model consists of an array with three columns of the format [depth Vp Vs]. The 
current velocity models all go up to 12 km above sea level (-12.0 km) because the 
sample model domain goes to -10 km. The velocity model must be defined across the 
entire depth range of the model domain. Note that while the velocity model may 
contain sharp discontinuities, velocity gradients are limited in the actual starting 
model by node density. For example, if the Moho is at 36 km depth, but depth nodes 
are defined at 30 km depth and 40 km depth, velocity across the Moho will be linearly 
interpolated across the Moho from 30-40 km depth. However, in the ray tracing 
algorithm, the Moho is explicitly defined such that Ps conversions are generated at 
36 km depth.

The next part of the code is all set up prior to iterating through the inversion. In 
the section "Set up initial inversion iteration", two variables are defined. "delay" 
is defined using the delay times included in the input file. This is the data to 
which predicted delay times will be compared prior to each inversion. "imod" is also 
defined as the starting model determined using "getStartModel.m". "imod" is updated 
in each inversion iteration to reflect the updated model determined by inversion. 
"smodel" will never change and is maintained as a baseline model for which later 
models are compared. In the section "Initialize iterated variables", a number of 
variables are initialized to retain data from each iteration, as defined by "n_iter" 
in the call script. This way intermediate iterations can be evaluated, as well as the 
evolution of the forward problem and inversion statistics. 

Next we have the iterated inversion. For each iteration, using the current velocity 
model "smod" (copied from "imod"). the defined model domain, and the data 
configuration, the forward problem is modelled to determine predicted ray paths, 
predicted travel times, and ultimately our inversion matrix G. This is all done in 
"fwdCalc.m" and utilizes the "fm3d" function of the "fmtomo" code described earlier.

fwdCalc.m
This is the most "complex" part of the code, mostly because of difficult bookkeeping.
The whole script is designed around setting up and running "fm3d". "fm3d" operates by 
reading several files with generic names in the local directory and depositing 
generically-named output files in the same directory. Several of the input files do 
not need to change from one run to the next, so they are stored in the "Library". 
Others rely on data in the MATLAB workspace and so need to be created. "fwdCalc.m" 
takes data from MATLAB, writes them to files strategically runs "fm3d", and then 
extracts data from the output files and reads them to MATLAB memory for use. The 
result of the script is a predicted delay time vector "d_pred", and a G matrix "G".
	First, some bookkeeping. "addpath" is used to ensure that all functions are 
accessible even when migrating to other directories. "fm3d_path" is then defined as 
the location of the executable "fm3d" on your machine. This MUST be changed prior to 
use and is the one part of the code that will break using the example files if not 
changed for your machine. 
	The files that need to be created for "fm3d" can be classified either as 
"universal" for a tomography iteration, meaning they apply equally to all events, or 
"unique" to a specific event. The next step is to create the universal input files 
using "writeUniversalInputs.m". More on that below, but for now just know that this 
creates a velocity grid file "vgrids.in", a propagation grid file "propgrid.in", and 
an interface file "interfaces.in", and copies the appropriate files from the 
"Library".
	"fm3d" is run in directories two levels down from the main directory. An 
overarching directory called "Run_fm3d" houses most of what is used in this script, 
but "fm3d" is actually run in subdirectories within "Run_fm3d" called "Run1", "Run2", 
etc. As it comes, there are 8 "Run" subdirectories. These exist to allow for 
parallelization across 8 subprocesses. If your computer can further parallelize, you 
can use them by a) adding as many "Run" directories as needed, b) changing "nproc" 
which defines the number of subprocesses to run at once, and c) adding corresponding 
lines that copy files to the subdirectories (start with "[~,~]". On the other hand, 
if you either cannot run in parallel or need to run fewer than 8 subprocesses, simply 
change the value of "nproc". To de-parallelize altogether, you will want to change 
"parfor" to "for" later in the script and comment out the "if" statement that runs 
"parpool".
	The way parallelization works with this code is that "fm3d" is currently set 
up to run once for each unique event in which we have recorded delay times. The run 
of "fm3d" for each event is independent of the others, and so multiple events can be 
run in parallel. To do this, events are allocated to separate directories in which 
"fm3d" is called. They need to separated to different directories so that files are 
not overwritten by separate "fm3d" runs. Universal input files need to be distributed 
to each "Run" directory using the "unix" lines. Then events are allocated directories 
using the "direc" variable. Essentially, each event is given a number from 1 to 
"n_proc" which determines which "Run" directory it will be evaluated in.
	The "parfor" loop is the crux of this script, though it can be changed to a 
"for" loop if you prefer to not run in parallel. The outer loop simply defines the 
parallelization, ensuring that each process runs separately. Each processor 
independently navigates to the relevant "Run" directory to cycle through the events 
that were allocated to it (interior loop). For each iteration of the inner loop (that 
is, for each unique event), the first thing to happen is that the unique input files 
needed for that event are generated using "writeUniqueInputs.m". More on that script 
below, but the main thing to know is that it generates two input files specific to 
the current event: a) "sources.in" which will define a single source, and 
b) "receivers.in" which will identify all of the stations that have delay times from 
that source. After all input files are created, "fm3d" is run through the "unix" 
system. "fm3d" will create two relevant output files: "rays.dat" and "arrivals.dat". 
"rays.dat" contains ray paths for both the direct teleseismic phase and the converted 
Ps phase for every relevant station from that event. "arrivals.dat" contains the 
predicted travel times from the source to the receiver for each of those phases. 
These files are renamed with an ID number so they can be properly referenced later 
and are saved in directories "Rays" and "Arrivals", which collect output files from 
all "Run" directories. This step is essential to ensuring output files are not 
overwritten by subsequent "fm3d" runs. Note that input and output files are 
remaining in each of "Run", "Rays", and "Arrivals" directories from my most recent 
tomography run (the example run) to serve as examples of what these files can/should 
look like.
	After "fm3d" is run for every unique event, each event is cycled through 
again to read its saved "Arrivals" and "Rays" output file. This is performed using 
"getArrivals.m" and "getRays.m", respectively. More on those scripts below, but they 
have the effect of extracting ray path and travel time information from the files and 
saving them to memory in variables "p_pred_i" and "s_pred_i" (predicted travel times 
for direct P and Ps phases, respectively), and "ray_p" and "ray_s" (predicted ray 
paths for direct P and Ps phases, respectively), respectively.
	Because this version of the technique assumes a fixed P wave velocity 
structure, the direct P ray path is not needed. Instead, we use "calcRayNodes.m" to 
use the crust S portion of the Ps path, along with the curent S wave model, to 
determine sensitivity kernels for the given event and save them to variable 
"sray_coeff". More on "calcRayNodes.m" below. These are then indexed to the correct 
portion of the G matrix.
	Finally, predicted Ps-P delay times are determined simply by subtracting the 
predicted direct P travel time from the predicted Ps travel time, as extracted from 
"arrivals.dat".

***Note that the unix commands in this script may need to be adapted for non-unix 
platforms.

writeUniversalInputs.m
"writeUniversalInputs.m" writes three files that define the model domain used by 
"fm3d", so they apply to every event for a given iteration. These are extracted from 
the model domain defined in "domain", the Moho geometry defined in "Moho", and the 
velocity model defined in "smod". The files, called "vgrids.in", "propgrid.in", and 
"interfaces.in" follow specific formats, and more details about the formatting can 
be found in the "fm3d" and "fmtomo" documentation.
	The first to be created is "vgrids.in". Because we are dealing with 
Moho-generated converted phases, we have a domain divided into crust and mantle by 
the Moho. The crust is defined from the surface to the Moho and the mantle is defined 
from the Moho to the the base of the model domain. Therefore, "vgrids.in" needs to 
define four distinct velocity grids, a P wave grid and S wave grid each defined in 
the crust and each defined in the mantle. It is important to note that all four grids 
will technically be defined across the entire model domain (surface to model base), 
but will only be utilized where appropriate. The mantle grids will always be defined 
using the initial starting velocity model (extracted again using "interpvel1D.m"), 
which will generally consist of a global reference model in the mantle (ie. AK135). 
The crustal grids will consist of the starting velocity model for the current 
iteration. In the context of a fixed Vp, only the crustal S wave model will change 
from iteration to iteration, and this will reflect the current 3D absolute Vs model. 
Due to necessity of the "fm3d" code, each velocity model must include extra nodes 
around the edges and on the top and bottom of the velocity model. In each case, these 
are copied from the nearest edge or layer, respectively. A couple quirks of 
"vgrids.in" to note include that latitude and longitude are defined in radians, that 
depth is defined in terms of radius (distance from the center of the earth), and that 
the grid "origin" is defined as the topmost southwest corner of the model domain. 
The velocity grids are actually written to file in the section "Write velocity grid 
file" in the order P wave crust (3D), P wave mantle (background), S wave crust (3D), 
S wave mantle (background).
	The next to be created is "propgrid.in", or the propagation grid, in section 
"Write propagation grid file". This defines the region over which to propagate the 
wavefront, which should be contained within the velocity grid by several nodes. This 
determines "resolution" of the wavefront tracking through a medium defined by the 
velocity grids. I have chosen here to make lateral spacing half of the velocity node 
spacing, as denoted by dividing node spacing by 2 at the top of the section, but this 
can likely be changed to reflect individual needs or computational requirements. 
Another part of this file that can be changed for other purposes are the two "5"s 
identified as dummy variables that describe the near-source refinement factor. These 
exist for when earthquake sources are within the model domain. In our case, they are 
not, and so are arbitrary. If using local phases, be careful with these numbers as 
high refinement factors can exponentially increase run time and have crashed my 
computer before.
	The last universal input file to be created is "interfaces.in" in the section 
"Write interface file". This file most notably defines the Moho used to generate 
conversions. In reality, three interfaces are printed to this file (in terms of 
radius) at the same grid nodes defined for the velocity grid. These include the 
surface (which can be placed arbitrarily high to ensure wavefronts are measured to 
the station), the Moho, and the base of the model (which could be arbitrarily low to 
ensure the entire Moho converter is captured). Currently the surface and base of the 
model are defined as the shallowest and deepest node layers. The Moho is defined by 
interpolating the Moho defined in variable "Moho".
	Finally, unchanging input files are copied from the "Library". These include 
two "fm3d"-specific files "mode_set.in" and "frechet.in", which define relatively 
standard parameters, and several files regarding the "ak135" velocity model. These 
contain the information needed to calculate the out-of-box (near source) component of 
teleseismic rays/travel times. It is not unreasonable to replace these files with 
information for another earth model, but that is not something I have tried.

writeUniqueInputs.m
"writeUniqueInputs.m" writes two files that define the specific event/phase/station 
configurations to calculate travel times and ray paths for. For a given event, this 
script writes the files that define that event and the stations that record it. 
	In the first part of the script, "Write source input file", the file 
"sources.in" is written. Given that it is currently set up to only assess one event 
at a time, this file is divided into sections for each station sampling that event, 
and each looks identical. Each section explains that for each station we are 
interested in two teleseismic paths, or two rays, and that these consist of a P wave 
transmitted as a P wave at the Moho and a P wave converted to an S wave at the Moho.
	The second part of the script "Write receiver input file" writes the file 
"receivers.in". This simply defines station locations and acknowledges that each 
station needs calculations for both phases.

getArrivals.m
Extracting arrival times from "arrivals.dat" files using "getArrivals.m" is very easy 
as long as the stations were properly indexed in "receivers.in". The output file 
"arrivals.dat" should contain two lines per event, one each containing the direct P 
and the Ps travel times for each station. Thus, "getArrivals.m" just has to separate 
those into variables output as "p_pred_i" and "s_pred_i".

getRays.m
Extracting ray paths from "rays.dat" files using "getRays.m" is less straight
forward. The output file "rays.dat", given the organization of our input files, will 
provide four ray segments per station corresponding to the four path segments denoted 
in "sources.in". We are only interested in one of these segments - the crustal S 
portion of the Ps phase - so this phase needs to be parsed out. This is accomplished 
in "getRays.m" using a complex set of regular expressions to identify which segment 
is the crustal S path. However, the crustal P portion of the direct P phase is also 
saved to a variable in case it becomes desirable to invert for both P and S velocity.

calcRayNodes.m
"calcRayNodes.m" is used to calculate note sensitivities for each ray using the 
crustal S ray path and the current velocity model. To do this, each ray is 
discretized at regular intervals. Currently it is set to be discretized at 1/2 of the 
node spacing, with a maximum at 1 km (variable "ray_int_max"). In the example, node 
spacing is 10 km, with half being 5 km, so it defaults to 1 km discretization. 
Discretization smooths out the ray. Then, each discrete ray segment is defined by its 
midpoint in three dimensions. Note that this process is aided by a script, 
"distCalc.m", which is described below. Each ray segment midpoint is then used to 
define sensitivity of the nodes around it using two scripts: "findNodes.m" and 
"nodeWeights.m". These identify the eight nodes surrounding the midpoint and 
determine how much to weight each of those nodes, as described below. Sensitivities 
are determined using an equation described in the accompanying paper's supplement 
that includes the velocity at the midpoint location, the length of the segment, and a 
weighted average of the velocities of the surrounding midpoints. Sensitivities for 
each ray segment are summed to define the sensitivities for the entire ray. These 
sensitivities populate the G matrix.

distCalc.m
"distCalc.m" is a utility to calculate the straight-line distance between two points 
in a sphere defined by spherical coordinates latitude, longitude, and radius.

findNodes.m
"findNodes.m" takes arbitrary x, y, z points in the rectangular model domain and 
finds the indices of the surrounding eight nodes. This utility relies on a model 
domain in which every lateral node exists at every depth layer, and vice versa. This 
is the case for the current code base, but should be considered when adjusting the 
code to have a different model domain setup, such as having sampling-dependent node 
density. The size of the output vector of indices "indx" will be reduced from eight 
if the point is located within a nodal plane. For example, a point (x,y,z) that is 
identically located to the position of a node will only output one index - the index 
of that node. This is because the point's location is defined by only a single node.

nodeWeights.m
"nodeWeights.m" uses a type of tri-linear weighting scheme to assign weights to the 
surrounding nodes determined using "findNodes.m". In this scheme, the nearest node 
will garner the highest weight and the furthest node will garner the lowest weight.

That concludes the section on "fwdCalc.m", which produced predicted Ps-P delay times 
and a G matrix. The next step simply determines our data vector "d" by comparing 
predicted delay times "d_pred" to those provided in the input file "delay". These are 
called delay time residuals. If a residual cutoff was selected in the call script 
("use_cutoff" set to "true"), then this is where outliers are removed. Any lines in 
the data vector and G matrix corresponding to residuals exceeding the prescibed 
threshold "cutoff" are set to zero, effectively removing them from the inversion. The 
indices of the removed data "r_indx" are saved to variable "d_rems" for analysis, as 
needed.

hitCount.m
At this point, "hitCount.m" determines the number of rays that sample each node and 
saves this to vector "hc". This is done by simple counting the number of non-zero 
entries in G corresponding to each node.

The next step is to determine our regularization matrix "E". "E" is an identity 
matrix scaled by a damping value defined in the call script as "damp". This damping 
matrix is then used in the construction of the inverse operator, "inv(G'*G+E)*G'". 
The inversion is performed by multiplying the inverse operator by the data vector to 
get model "m", consisting of velocity perturbations. The resolution matrix "R" is 
determined by multiplying the inverse operator by "G".
	The last important step of the iteration is to reset the current velocity 
model "imod" using the model updates "m". First, the model updates are converted to a 
new S wave velocity model "vm". Then "vm" replaces the S wave portion (second column) 
of the in-use velocity model "imod". Note that the model update "m" updates "smod", 
which is set at the beginning of the iteration to match "imod". The rest of the 
iteration consists of performing basic statistics and saving variables for analysis 
at your leisure.
	This is then performed iteratively for the number of iterations set by 
"n_iter" in the call script.

THE END
