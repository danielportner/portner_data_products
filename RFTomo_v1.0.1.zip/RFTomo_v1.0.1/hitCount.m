function [ hc ] = hitCount(G)

% Determines the number of rays sampling each node using G
%
% Written DEP 16 Mar 2020

[ n, m ] = size(G) ;
hc = zeros(m,1) ;
for i = 1:m
    col = G(:,i) ;
    hits = length(col(col~=0)) ;
    hc(i) = hits ;
end

end

