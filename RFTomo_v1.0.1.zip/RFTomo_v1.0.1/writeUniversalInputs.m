function writeUniversalInputs(domain,vmodel)

% Prepares input files for fm3d that are used for each ray
%
% After OutputModel_DoFmm, Read3Dmodel_prepgrid, and
%   WriteSourceReceiver from C. Jiang
%
% Written DEP 24 Feb 2020
% Edited DEP 1 Apr 2020 to make starting model a variable
% Edited DEP 6 Apr 2020 to allow for an assigned crustal Vs for model 3
% Edited DEP 9 Apr 2020 to allow for a variable Moho
% Edited DEP 7 May 2020 to exclude boundary nodes from average node spacing
%   calculation

vm = vmodel ;
mlat = domain.mlat ; mlon = domain.mlon ;
modz = domain.modz ;
nx = domain.nx ; ny = domain.ny ;
dz = domain.dz ;

% Determine average horizontal node spacing in lat/lon
mlat1 = reshape(mlat(1:nx*ny),[ny,nx]) ;
mlon1 = reshape(mlon(1:nx*ny),[ny,nx]) ;

% Calculate average node spacing, excluding buffer node
dlat = mean(mean(mlat1(3:end-1,:)-mlat1(2:end-2,:)))/2 ;
dlon = mean(mean(mlon1(:,3:end-1)-mlon1(:,2:end-2)))/2 ;

% do a 2D interpolation at each depth
lats = min(mlat):dlat:max(mlat) ;
lons = min(mlon):dlon:max(mlon) ;
[ latgrid, longrid ] = meshgrid(lats,lons) ;

% Calculate an interpolated Moho at lats/lons
F = scatteredInterpolant(domain.Moho.lat,domain.Moho.lon,domain.Moho.depth,'natural') ;
gMoho = F(latgrid,longrid) ;

int_model = zeros(length(lats)*length(lons)*length(modz),5) ;
n = 1 ;
for i = 1:length(modz)
    id = find(domain.mz==modz(i)) ;
    F = scatteredInterpolant(mlat(id),mlon(id),vm(id,1),'natural') ;
    nvmp = F(latgrid,longrid) ;
    F = scatteredInterpolant(mlat(id),mlon(id),vm(id,2),'natural') ;
    nvms = F(latgrid,longrid) ;
    for j = 1:length(lons)
        for k = 1:length(lats)
            jkmoho = gMoho(longrid == lons(j) & latgrid == lats(k)) ;
            if (isnan(nvmp(j,k)))
                nvmp(j,k) = interpvel1D(domain.vmod,1,jkmoho,domain.vs_crust,modz(i)) ;
            end
            if (isnan(nvms(j,k)))
                nvms(j,k) = interpvel1D(domain.vmod,2,jkmoho,domain.vs_crust,modz(i)) ;
            end
            int_model(n,:) = [ lats(k) lons(j) modz(i) nvmp(j,k) nvms(j,k) ] ;
            n = n+1 ;
        end
    end
end

lat = int_model(:,1) ;
lon = int_model(:,2) ;
dep = int_model(:,3) ;
pvel = int_model(:,4) ;
svel = int_model(:,5) ;
nlat = unique(lat) ;
nlon = unique(lon) ;

% expand model to add nodes on top and bottom
idep = modz' ;
idep = [ idep(1) ; idep(1) ; idep ; idep(end)+dz ; idep(end)+2*dz ] ;
nvelp = zeros([length(nlon),length(nlat),length(idep)]) ;
bvelp = zeros([length(nlon),length(nlat),length(idep)]) ;
nvels = zeros([length(nlon),length(nlat),length(idep)]) ;
bvels = zeros([length(nlon),length(nlat),length(idep)]) ;

% Populate 3D model and background models 
for i = 1:length(nlon) ;
    for j = 1:length(nlat)
        % Get background model profile from 1D start model
        ijmoho = gMoho(longrid == nlon(i) & latgrid == nlat(j)) ;
        bmodel = interpvel1D(domain.vmod,3,ijmoho,domain.vs_crust,idep) ;
        for k = 1:length(idep)
            bvelp(i,j,k) = bmodel(k,1) ;
            nvelp(i,j,k) = bmodel(k,1) ;
            bvels(i,j,k) = bmodel(k,2) ;
            nvels(i,j,k) = bmodel(k,2) ;
        end
        for k = 3:length(idep)-2
            nvelp(i,j,k) = pvel(lon==nlon(i)&lat==nlat(j)&dep==idep(k)) ;
            nvels(i,j,k) = svel(lon==nlon(i)&lat==nlat(j)&dep==idep(k)) ;

        end
    end
end

% Copy top real layer into upper buffer layers for 3D grid
nvelp(:,:,1) = nvelp(:,:,3) ; nvelp(:,:,2) = nvelp(:,:,3) ;
nvels(:,:,1) = nvels(:,:,3) ; nvels(:,:,2) = nvels(:,:,3) ;

%% Write velocity grid file
% common variables
ngrids = 2 ; % 2 grids between 3 interfaces
ntypes = 2 ; % 2 means both Vp and Vs grids

% initialize vgrids.in
fid = fopen('Run_fm3d/vgrids.in','w+') ;

% print number of velocity layers and number of velocity types
fprintf(fid,' %d %d\n',ngrids,ntypes) ;

for i = 1:ntypes % loop through Vp and Vs
    for j = 1:ngrids % loop through 3D and background vgrids
        % print number of grid nodes (radius, lat, lon)
        fprintf(fid,' %d %d %d\n',length(idep),length(nlat),length(nlon)) ;
        % print grid node spacing (radius (km), lat (radians), lon (radians))
        fprintf(fid,' %4.5f %1.8E %1.8E\n',dz,dlat*pi/180,dlon*pi/180) ;
        % print origin of velocity grid (radius (km), lat (radians), lon (radians))
        fprintf(fid, '%4.5f %1.8E %1.8E\n',6371-idep(end),lat(1)*pi/180,lon(1)*pi/180) ;
        
        for k = 1:length(idep) % Loop radius
            for l = 1:length(nlat) % loop latitude
                for m = 1:length(nlon) % loop longitude
                    % print velocities (km/s)
                    if i == 1
                        if j == 1
                            fprintf(fid,'%2.4f\n',nvelp(m,l,end-k+1)) ;
                        elseif j == 2
                            fprintf(fid,'%2.4f\n',bvelp(m,l,end-k+1)) ;
                        end
                    elseif i == 2
                        if j == 1 
                            fprintf(fid,'%2.4f\n',nvels(m,l,end-k+1)) ;
                        elseif j == 2
                            fprintf(fid,'%2.4f\n',bvels(m,l,end-k+1)) ;
                        end
                    end
                end
            end
        end
    end
end

%% Write propagation grid file
% Make grid node spacing half of velocity grid node spacing
dlonp = dlon/2 ;
dlatp = dlat/2 ;

% Make sure at least two vgrid nodes outside of propagation grid
%   (here using 3)
lonsp = (lons(i)+3*dlon):dlonp:(lons(end)-3*dlon) ;
latsp = (lats(i)+3*dlat):dlatp:(lats(end)-3*dlat) ;
idepp = modz' ;

% initialize propgrid.in
fid = fopen('Run_fm3d/propgrid.in','w+') ;

% Print propgrid header
%   print number of grid nodes (radius, lat, lon)
fprintf(fid,' %d %d %d\n',length(idepp),length(latsp),length(lonsp)) ;
%   print grid node spacing (radius (km), lat (deg), lon (deg))
fprintf(fid,' %3.1f %3.8f %3.8f\n',dz,dlatp,dlonp) ;
%   print origin of velocity grid (depth (km), lat (deg), lon (deg))
fprintf(fid,' %2.3f %2.5f %2.5f\n',-1*idepp(1),(lats(i)+3*dlat),(lons(i)+3*dlon)) ;
%   print dummies for near-source refine factor
fprintf(fid,' 5 5') ;

fclose(fid) ;

%% Write interface file
ninter = 3 ; % 3 interfaces (1 internal)

% Initialize interfaces.in
fid = fopen('Run_fm3d/interfaces.in','w+') ;

fprintf(fid,' %d\n',ninter) ; % print number of interfaces
% print number of grid nodes (lat, lon)
fprintf(fid,' %d %d\n',length(nlat),length(nlon)) ;
% print grid node spacing (lat (radians), lon (radians))
fprintf(fid,' %1.8E %1.8E\n',dlat*pi/180,dlon*pi/180) ;
% print origin of interface grid (lat (radians), lon (radians))
fprintf(fid, ' %1.8E %1.8E\n',lat(1)*pi/180,lon(1)*pi/180) ;

for i = 1:ninter
    for j = 1:length(nlat)
        for k = 1:length(nlon)
            if i == 1
                % Print surface interface (at shallowest node depth
                fprintf(fid,' %4.10f\n',6371-idepp(1)) ;
            elseif i == 2
                % Print moho interface
                jkmoho = gMoho(longrid == nlon(k) & latgrid == nlat(j)) ;
                fprintf(fid,' %4.10f\n',6371-jkmoho) ;
            elseif i == ninter
                % Print base of model interface
                fprintf(fid,' %4.10f\n',6371-idepp(end)) ;
            end
        end
    end
end

fclose(fid) ;

%% Unedited inputs
% Make sure these input files are in the Run_fm3d directory

[~,~] = unix('cp Library/mode_set.in Run_fm3d');
[~,~] = unix('cp Library/frechet.in Run_fm3d');
[~,~] = unix('cp Library/ak135.hed Run_fm3d');
[~,~] = unix('cp Library/ak135.tbl Run_fm3d');
[~,~] = unix('cp Library/ak135.tvel Run_fm3d');

end


