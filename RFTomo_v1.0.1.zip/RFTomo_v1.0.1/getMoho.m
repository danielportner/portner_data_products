function [ Moho ] = getMoho(type,domain,base)

% Determines a Moho over the model domain that is isostatically compensated
%   with respect to a given crustal thickness at 0 elevation
%
% Written DEP 05 Apr 2020
% Edited DEP 11 Jul 2022 to include type 3, a Moho uploaded from file

% Determine lat/lons to sample
samp_lat = domain.mlat(1:domain.nx*domain.ny) ;
samp_lon = domain.mlon(1:domain.nx*domain.ny) ;
samp_x = domain.mx(1:domain.nx*domain.ny) ;
samp_y = domain.my(1:domain.nx*domain.ny) ;
Moho.lat = samp_lat ; Moho.lon = samp_lon ;
Moho.x = samp_x ; Moho.y = samp_y ;

% Get elevation info
topoFile = 'Library/ETOPO1_Bed_g_gmt4_cut_MSH.xyz' ;
% Load topography data
fid = fopen(topoFile, 'r') ;
A = [textscan(fid, '%f %f %f'),1];
fclose(fid) ;

topo.lon = A{1} ;
topo.lat = A{2} ;
topo.el = A{3} ;
% Interpolate over model domain
elevs = griddata(topo.lon,topo.lat,topo.el/1000,samp_lon,samp_lat) ;
Moho.elevs = elevs ;

if type == 1 % Flat Moho
    depths = ones(size(samp_lat))*base ;
    Moho.depth = depths ;
elseif type == 2 % Isostatic Moho
    p_oc = 3000 ; % Density of the oceanic crust (kg/m^3)
    p_ml = 3300 ; % Density of the mantle (kg/m^3)

    % Calculate isostatic Moho for entire grid
    moho = zeros(length(topo.el),1) ;
    for i = 1:length(moho)
        moho(i) = (p_oc*topo.el(i)/(p_ml-p_oc))/1000+base ;
    end

    % Interpolate over model domain
    depths = griddata(topo.lon,topo.lat,moho,samp_lon,samp_lat) ;
    
    Moho.depth = depths ;
elseif type == 3 % Uploaded Moho from file
    % Get Moho info
    mohoFile = 'Library/sampleMoho_msh.txt' ;
    % Load Moho data
    fid = fopen(mohoFile, 'r') ;
    A = [textscan(fid, '%f %f %f'),1];
    fclose(fid) ;

    moho.lon = A{1} ;
    moho.lat = A{2} ;
    moho.dep = A{3} ;
    % Interpolate over model domain
    tmp_moho = griddata(moho.lon,moho.lat,moho.dep,samp_lon,samp_lat) ;
    Moho.depth = tmp_moho ;
end
end
