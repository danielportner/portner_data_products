function [ vel ] = interpvel1D(velmod,PS,moho,vs_crust,deps)

% Calculates the 1D velocity profile at a given 
% set of depths 
%
% After get_vel_1D from B. Schmandt
%
% Written DEP 22 Feb 2020
% Edited DEP 6 Apr 2020 to allow for an assigned crustal Vs for model 3

% Input deps must be vertical vector
% velmod = 1 (ak135-f)
% PS = 1 (Vp), 2(Vs), 3(Vp,Vs)

vmodel = getvel1D(velmod,moho,vs_crust) ;

depth = vmodel(:,1) ;
if PS == 1 % P-wave velocities
    refvel1 = vmodel(:,2) ;
    vel = interp1(depth,refvel1,deps) ;
elseif PS == 2 % S-wave velocities
    refvel2 = vmodel(:,3) ;
    vel = interp1(depth,refvel2,deps) ;
elseif PS == 3 % Determine a Vp and a Vs starting model
    refvel1 = vmodel(:,2) ;
    refvel2 = vmodel(:,3) ;
    vel1 = interp1(depth,refvel1,deps) ;
    vel2 = interp1(depth,refvel2,deps) ;
    vel = [ vel1 vel2 ] ;
end
        
end

