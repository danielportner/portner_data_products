%---------- dampingTradeoff ----------%
%
% dampingTradeoff performs tradeoff analysis for a series of damping
%   parameters, running the forward problem twice each time
%

%% Define parameters
% Data file
delayFile = 'InputFiles/sampleInput_cleveland.dat' ; % Input data file

% data residual cutoff (s) - negative will be -1*cutoff
use_cutoff = true ; cutoff = 1.0 ;

% Damping parameters to test
damp_vals = [ 5 10 20 50 100 ] ; % epsilon^2 damping parameter

% Model domain parameters
origin = [ 52.82 -169.95 ] ; % Reference point for model domain [ lat lon ]
dx = 10 ; dy = 10 ; dz = 10 ; % Node spacing in x, y, and z dimensions
pad = 30 ; % Lateral distance beyond stations for model domain 
zrange = [ -10 50 ] ; % Depth range for model (negative is above sea level)

% Velocity model parameters
% vmod: refmod 1 = ak135, 2 = uniform crust with assigned Vs 
%   vmod = 2 requires a vs_crust value
vmod = 2  ; 
vs_crust = 3.7 ; % only for vmod = 2
% moho_type: 1 = flat Moho, 2 = pseudo-isostatic Moho, 3 = variable center Moho
moho_type = 3 ; 
smoho = 36 ; % Starting moho depth (for moho_type 2, is Moho at sea level)
mcent = 44 ; % Model center Moho - only needed for Moho_type = 3

%% Read data
% Name input file
[ data ] = readData(delayFile) ;

%% Setup model domain
[ stax,stay ] = latlon2xy(data.ray.stalat,data.ray.stalon,origin) ;
data.ray.stax = stax ; data.ray.stay = stay ;
[ data.sta.x,data.sta.y ] = latlon2xy(data.sta.lat,data.sta.lon,origin) ;

domain = setupDomain(data,origin,zrange,dx,dy,dz,pad) ;
domain.vmod = vmod ; % Include velocity model variable
domain.vs_crust = vs_crust ;
domain.moho_type = moho_type ;
domain.mcent = mcent ; 

%% Determine starting model
% Determine Moho across study area
domain.smoho = smoho ; % Baseline moho (flat Moho or sea-level Moho)
Moho = getMoho(moho_type,domain,smoho,mcent) ;
domain.Moho = Moho ;

% Determine velocity model
smodel = getStartModel(vmod,Moho,domain) ;
domain.smodel = smodel ;

%% Set up initial inversion iteration
delay = data.ray.delay ; % Observed Ps-P delay time
imod = smodel ; % imod is used as the iterative starting model

% Run initial forward model
smod = imod ;
[ d_pred, G0 ] = fwdCalc(data,domain,smod) ;

G = G0 ;

% Calculate delay time residuals
d =  delay - d_pred ;
    
% Remove outlier data
if use_cutoff == true
    % Determine outlier data to remove
    r_indx1 = find(d>cutoff) ;
    r_indx2 = find(d<(-1*cutoff)) ;
    r_indx = [ r_indx1 ; r_indx2 ] ;
    fprintf(' Removing %d data\n',length(r_indx) );
    
    % Create vector of removed data
    d_rems = r_indx ;
    
    % Remove outliers
    d(r_indx) = 0 ;
    G(r_indx,:) = 0 ;
end
    
% Determine hit count
hc = hitCount(G) ;

%% Initialize variables to save
d_preds = zeros(data.ray.nrays,length(damp_vals)) ; % Predicted Ps-P using fmtomo
dfs = zeros(data.ray.nrays,length(damp_vals)) ; % Ps-P residuals from forward model G*m
ms = zeros(domain.nmod,length(damp_vals)) ; % Output model perturbations from inversion
mns = zeros(domain.nmod,length(damp_vals)) ; % Model perturbations relatie to initial model
vms = zeros(domain.nmod,length(damp_vals)) ; % Output Vs velocity model calculated from perturbations
Rdiags = zeros(domain.nmod,length(damp_vals)) ; % Resolution matrix diagonals
norm_mns = zeros(length(damp_vals),1) ; % Norm of the model relative to initial model
dnorms = zeros(length(damp_vals),1) ;
drnorms = zeros(length(damp_vals),1) ;

%% Cycle through damping values
% Damped least squares, direct inversion, least squares form
for i = 1:length(damp_vals)
    tic
    damp = damp_vals(i) ;
    damps = damp*ones(domain.nmod,1) ;

    reg_mat = diag(damps) ;
    E = reg_mat ;
    Ginv = inv(G' * G + E) * G' ;
    R = Ginv * G ;
    m = Ginv * d ;

    vm = (1+m) .* smod(:,2) ; % Absolute velocity model
    
    imod(:,2) = vm ; % Will be starting model for next iteration
    
    % Calculate model norm and variance reduction
    df = G * m ;
    
    % Calculate total model norm
    mn = (vm-smodel(:,2))./smodel(:,2) ; % Cumulative model as percent deviations
    norm_mn = norm(mn) ;
    
    %% Re-run forward problem
    [ d_pred2, ~ ] = fwdCalc(data,domain,imod) ;
    
    d_new = delay - d_pred2 ;

    %% Save iteration data
    d_preds(:,i) = d_pred2 ;
    dfs(:,i) = df ;
    ms(:,i) = m ;
    mns(:,i) = mn ;
    vms(:,i) = vm ;
    Rdiags(:,i) = diag(R) ;
    norm_mns(i) = norm_mn ;
    dnorms(i) = norm(d_new) ;
    if use_cutoff == true
        d_new(r_indx) = 0 ;
    end
    drnorms(i) = norm(d_new) ;
    
    fprintf(' Damp = %d \n',damp_vals(i) );
    fprintf(' Data misfit norm = %f, L2 model norm = %f \n',norm(delay-d_pred2),norm_mn );
    toc
end
save('Saved/tmp.mat','-v7.3') ;