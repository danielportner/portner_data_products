function [ data ] = readData(delayFile)

% Reads delay times from input file into a
% usable structure
%
% After ReadData from B. Schmandt
%
% Written DEP 21 Feb 2020
% Edited DEP 20 Mar 2020 to add evt variable with separate event info and
%   sta variable with separate station info
% Edited DEP 23 Mar 2020 so that a new event ID is determined in code,
%   rather than taken from the input. Input event ID and in-code event ID
%   will no longer match up because in-code event ID is dependent on phase.

fid = fopen(delayFile, 'r') ;
A = [textscan(fid, '%d %f %f %f %s %f %f %f %s %f'),1];
fclose(fid) ;

% Rename input data
ray.preid = A{1} ; % Input event ID is unused in code
ray.evlat = A{2} ;
ray.evlon = A{3} ;
ray.evdep = A{4} ;
ray.stanm = A{5} ;
ray.stalat = A{6} ;
ray.stalon = A{7} ;
ray.stael = A{8} ;
ray.ph = A{9} ;
ray.delay = A{10} ;
clear A
ray.nrays = length(ray.delay) ;
ray.rayid = [1:ray.nrays]' ;

ray.staid = zeros(size(ray.rayid)) ;
ray.phnum = zeros(size(ray.rayid)) ;
for i = 1:ray.nrays
    tmp_ph = ray.ph(i) ;
    if strcmp('P',tmp_ph{1})
        ray.phnum(i) = 1 ;
    elseif strcmp('PP',tmp_ph{1})
        ray.phnum(i) = 2 ;
    else
        ray.phnum(i) = 3 ;
        fprintf('Unidentified phase %s',phnum(i));
    end
end

% Separate event information
[~, ia, ic ] = unique([ray.evlat ray.evlon ray.evdep ray.phnum],'rows') ;
evt.lat = ray.evlat(ia) ;
evt.lon = ray.evlon(ia) ;
evt.dep = ray.evdep(ia) ;
evt.ph = ray.ph(ia) ;
evt.phnum = ray.phnum(ia) ;
evt.evid = [ 1:length(ia) ]' ;
evt.nevts = length(evt.evid) ;
% Assign an event ID to each ray
ray.evid = zeros(size(ray.delay)) ;
evt.nray = zeros(size(evt.evid)) ;
for i = 1:evt.nevts
    ray.evid(ray.evlat==evt.lat(i) & ray.evlon==evt.lon(i) & ...
        ray.evdep==evt.dep(i) & ray.phnum==evt.phnum(i)) = evt.evid(i) ;
    evt.nray(i) = length(ray.evid(ray.evid==evt.evid(i))) ;
end

% Separate station information
[ sta.stanm, ja, jc ] = unique(ray.stanm) ;
sta.lat = ray.stalat(ja) ;
sta.lon = ray.stalon(ja) ;
sta.el = ray.stael(ja) ;
sta.num = 1:length(sta.stanm) ;

% Add station numbers to ray data
for i = 1:length(sta.num)
    sta_indx = strcmp(sta.stanm{i},ray.stanm) ;
    ray.staid(sta_indx) = sta.num(i) ;
end

data.ray = ray ;
data.evt = evt ;
data.sta = sta ;
end

