function [ p_pred,s_pred ] = getArrivals(arrFile,n)

% Reads arrivals.dat to retrieve the predicted P and Ps travel times
%
% Written DEP 25 Feb 2020
% Edited DEP 20 Mar 2020 to accommodate multiple stations in output file

% Initialize output
p_pred = zeros(n,1) ;
s_pred = zeros(n,1) ;

% open file
fid = fopen(arrFile,'r') ;
A = textscan(fid,'%d %d %d %d %f %s %s') ;
fclose(fid) ;

times = A{5} ;

% Cycle through each expected station
k = 1 ;
i = 1 ;
while k < n*2
    p_pred(i) = times(k) ;
    s_pred(i) = times(k+1) ;
    i = i + 1 ;
    k = k + 2 ;
end