function [ lat,lon ] = xy2latlon(x,y,origin)

% Converts xy cartesian coordinates in km relative
% to a specified origin location to lat/lon
%
% After project_xy from B. Schmandt
%
% Written DEP 22 Feb 2020

% Set up map structure
mstruct = defaultm('mercator');
mstruct.origin = [origin 0];
mstruct = defaultm( mstruct );

% Convert to radians
x = km2rad(x,6371) ;
y = km2rad(y,6371) ;

[lat,lon] = minvtran(mstruct,x,y);

end

