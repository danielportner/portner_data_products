function [ x,y ] = latlon2xy(lat,lon,origin)

% Converts lat/lon coordinates to cartesian coordinates
% in km relative to a specified origin location
%
% After project_xy from B. Schmandt
%
% Written DEP 21 Feb 2020

% Set up map structure
mstruct = defaultm('mercator');
mstruct.origin = [origin 0];
mstruct = defaultm( mstruct );

% Determine x,y coordinates
[x,y] = mfwdtran(mstruct,lat,lon);

% Convert to km
x = rad2km(x,6371) ;
y = rad2km(y,6371) ;

end

