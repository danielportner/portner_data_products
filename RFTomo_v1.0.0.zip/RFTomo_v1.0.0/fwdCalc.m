function [ d, G ] = fwdCalc(data,domain,vmodel)

% Calculates predicted Ps-P delay times and a G matrix
%   given a model domain and velocity model
%
% After make_matrix from B. Schmandt and C. Jiang
%
% Written DEP 24 Feb 2020
% Edited DEP 20 Mar 2020 to run fm3d once per unique event
% Edited DEP 06 Apr 2020 to allow for an assigned crustal Vs for model 3
% Edited DEP 08 Apr 2020 to allow for a variable Moho

% Ensure functions are accessible
addpath(pwd)

% Identify path to fm3d executable
fm3d_path = '/Users/dportner/Projects/FMTOMO/fmtomo/bin/' ;

% Write fm3d input files that apply to all rays
writeUniversalInputs(domain,vmodel) ;

% initialize arrival vectors
p_pred = zeros(data.ray.nrays,1) ;
s_pred = zeros(data.ray.nrays,1) ;

% Initialize G
G = zeros(data.ray.nrays,domain.nmod) ;

% Copy universal input files into subdirectories
% We are hardcoded to 8 subprocesses
nproc = 8 ;
[~,~] = unix('cp Run_fm3d/*.in Run_fm3d/Run1');
[~,~] = unix('cp Run_fm3d/ak135.* Run_fm3d/Run1');
[~,~] = unix('cp Run_fm3d/*.in Run_fm3d/Run2');
[~,~] = unix('cp Run_fm3d/ak135.* Run_fm3d/Run2');
[~,~] = unix('cp Run_fm3d/*.in Run_fm3d/Run3');
[~,~] = unix('cp Run_fm3d/ak135.* Run_fm3d/Run3');
[~,~] = unix('cp Run_fm3d/*.in Run_fm3d/Run4');
[~,~] = unix('cp Run_fm3d/ak135.* Run_fm3d/Run4');
[~,~] = unix('cp Run_fm3d/*.in Run_fm3d/Run5');
[~,~] = unix('cp Run_fm3d/ak135.* Run_fm3d/Run5');
[~,~] = unix('cp Run_fm3d/*.in Run_fm3d/Run6');
[~,~] = unix('cp Run_fm3d/ak135.* Run_fm3d/Run6');
[~,~] = unix('cp Run_fm3d/*.in Run_fm3d/Run7');
[~,~] = unix('cp Run_fm3d/ak135.* Run_fm3d/Run7');
[~,~] = unix('cp Run_fm3d/*.in Run_fm3d/Run8');
[~,~] = unix('cp Run_fm3d/ak135.* Run_fm3d/Run8');

direc = zeros(data.evt.nevts,1) ;
for iev = 1:data.evt.nevts
    direc(iev) = ceil(nproc*iev/data.evt.nevts) ;
end

cd('Run_fm3d') ;
poolobj = gcp('nocreate');
if isempty(poolobj)
    parpool(nproc) ;
end

parfor iii = 1:nproc
    run_ind = find(direc == iii) ;
    cd(['Run' num2str(iii)]) ;
    for jjj = 1:length(run_ind)
        % Write fm3d input files that apply individually for each event
        writeUniqueInputs(data,run_ind(jjj)) ;
        % Ensure we're creating rays.dat and arrivals.dat file
        [~,~] = unix('rm rays.dat arrivals.dat') ;
        % Run fm3d
        [~,~] = unix([fm3d_path 'fm3d']);
        % Copy ray and arrivals files for later reading
        [~,~] = unix(['cp rays.dat ../Rays/rays' num2str(run_ind(jjj)) '.dat' ]);
        [~,~] = unix(['cp arrivals.dat ../Arrivals/arrivals' num2str(run_ind(jjj)) '.dat' ]);
    end
    cd('../');
end
cd('../');

% Cycle through each unique event
for i = 1:data.evt.nevts    
    
    evt_id = data.evt.evid(i) ;
    evt_indx = find(data.ray.evid == evt_id) ;
    nsta = length(evt_indx) ;
    
    % Extract predicted p and ps travel times from arrivals.dat
    afile = ['Run_fm3d/Arrivals/arrivals' num2str(i) '.dat' ] ;
    [ p_pred_i,s_pred_i ] = getArrivals(afile,nsta) ;
    p_pred(evt_indx) = p_pred_i ; s_pred(evt_indx) = s_pred_i ;
    
    % Extract raypaths from rays.dat
    rfile = ['Run_fm3d/Rays/rays' num2str(i) '.dat' ] ;
    [ ray_p,ray_s ] = getRays(rfile) ;

    % Calculate Ps ray sensitivites in the crust (Row in G matrix for that ray)
    sray_coeff = calcRayNodes(ray_s,domain,vmodel(:,2)) ;

    G(evt_indx,:) = sray_coeff ;
end
d = zeros(data.ray.nrays,1) ;
d = s_pred - p_pred ;

end

