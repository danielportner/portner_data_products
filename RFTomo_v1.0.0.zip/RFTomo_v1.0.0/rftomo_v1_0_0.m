%---------- rftomo ----------%
%
% rftomo is a simple tomography code built to invert Ps-P
%   delay times determined by receiver functions for crustal
%   structure
%

%% Read data
% Name input file
[ data ] = readData(delayFile) ;

%% Setup model domain
[ stax,stay ] = latlon2xy(data.ray.stalat,data.ray.stalon,origin) ;
data.ray.stax = stax ; data.ray.stay = stay ;
[ data.sta.x,data.sta.y ] = latlon2xy(data.sta.lat,data.sta.lon,origin) ;

domain = setupDomain(data,origin,zrange,dx,dy,dz,pad) ;
domain.vmod = vmod ; % Include velocity model variable
domain.vs_crust = vs_crust ;
domain.moho_type = moho_type ;
domain.mcent = mcent ;

%% Determine starting model
% Determine Moho across study area
domain.smoho = smoho ; % Baseline moho (flat Moho or sea-level Moho)
Moho = getMoho(moho_type,domain,smoho,mcent) ;
domain.Moho = Moho ;

% Determine velocity model
smodel = getStartModel(vmod,Moho,domain) ;
domain.smodel = smodel ;

%% Set up initial inversion iteration
delay = data.ray.delay ; % Observed Ps-P delay time
imod = smodel ; % imod is used as the iterative starting model

%% Initialize iterated variables
d_preds = zeros(data.ray.nrays,n_iter) ; % Predicted Ps-P using fmtomo
ds = zeros(data.ray.nrays,n_iter) ; % Ps-P residuals to invert
dfs = zeros(data.ray.nrays,n_iter) ; % Ps-P residuals from forward model G*m
ms = zeros(domain.nmod,n_iter) ; % Output model perturbations from inversion
mns = zeros(domain.nmod,n_iter) ; % Model perturbations relatie to initial model
vms = zeros(domain.nmod,n_iter) ; % Output Vs velocity model calculated from perturbations
hcs = zeros(domain.nmod,n_iter) ; % Hit count
Gs = zeros(data.ray.nrays,domain.nmod,n_iter) ; % Ray sensitivity matrix
Rdiags = zeros(domain.nmod,n_iter) ; % Resolution matrix diagonals
norm_mns = zeros(n_iter,1) ; % Norm of the model relative to initial model

%% Iterate through inversion
% Iterated
for i = 1:n_iter
    fprintf(' Starting iteration %d of %d\n',i,n_iter );
    tic
    %% Run forward model
    % Determine d and G
    % d_pred = predicted delay times
    % G = G matrix following 3D ray tracing
    % smodel must contain Vp and Vs models
    smod = imod ;
    [ d_pred, G ] = fwdCalc(data,domain,smod) ;
    
    % Calculate delay time residuals
    d =  delay - d_pred ;
    
    % Remove outlier data
    if use_cutoff == true
        % Determine outlier data to remove
        r_indx1 = find(d>cutoff) ;
        r_indx2 = find(d<(-1*cutoff)) ;
        r_indx = [ r_indx1 ; r_indx2 ] ;
        fprintf(' Removing %d data\n',length(r_indx) );
    
        % Create vector of removed data
        d_rems{i} = r_indx ;
    
        % Remove outliers
        d(r_indx) = 0 ;
        G(r_indx,:) = 0 ;
    end
    
    % Determine hit count
    hc = hitCount(G) ;
    
    %% Run inversion
    % Damped least squares, direct inversion, least squares form
    damps = damp*ones(domain.nmod,1) ;
    reg_mat = diag(damps) ;
    E = reg_mat ;
    Ginv = inv(G' * G + E) * G' ;
    R = Ginv * G ;
    m = Ginv * d ;

    vm = (1+m) .* smod(:,2) ; % Absolute velocity model
    
    imod(:,2) = vm ; % Will be starting model for next iteration
    
    % Calculate model norm and variance reduction
    df = G * m ;
    
    % Calculate total model norm
    mn = (vm-smodel(:,2))./smodel(:,2) ; % Cumulative model as percent deviations
    norm_mn = norm(mn) ;

    %% Save iteration data
    d_preds(:,i) = d_pred ;
    ds(:,i) = d ;
    dfs(:,i) = df ;
    ms(:,i) = m ;
    mns(:,i) = mn ;
    vms(:,i) = vm ;
    hcs(:,i) = hc ;
    Gs(:,:,i) = G ;
    Rdiags(:,i) = diag(R) ;
    norm_mns(i) = norm_mn ;
        
    % Print output
    fprintf(' Data misfit variance = %f, Total model norm = %f \n',var(d-df),norm_mn );
    toc
end

fprintf('Done.\n') ;
