function writeUniqueInputs(data,evt)

% Prepares input files for fm3d that are used for individual rays
%
% After OutputModel_DoFmm, Read3Dmodel_prepgrid, and
%   WriteSourceReceiver from C. Jiang
%
% Written DEP 25 Feb 2020
% Edited DEP 20 Mar 2020 to run fm3d once per unique event
% Edited DEP 23 Mar 2020 to mitigate a bug in fm3d by perturbing event
%   depth in sources.in
% Edited DEP 7 May 2020 to allow for parallel processing

evt_id = data.evt.evid(evt) ;
evt_indx = find(data.ray.evid == evt_id) ;
nsta = length(evt_indx) ;
evlat = data.evt.lat(evt) ;
evlon = data.evt.lon(evt) ;
evdep = data.evt.dep(evt) ;
ph = data.evt.ph(evt) ;
phase = ph{1} ;

% Add small increment to each depth to avoid an instability
%   in fm3d sometimes incurred when depth is an exact value
evdep = evdep+0.000001 ;

% Extract ray data
stalat = data.ray.stalat(evt_indx) ;
stalon = data.ray.stalon(evt_indx) ;
stael = data.ray.stael(evt_indx) ;

staelkm = -1*stael/1000 ; % station elevation in km depth (negative for above sea level)

%% Write source input file
% initialize sources.in
fid = fopen('sources.in','w+') ;

nevt = 1 ; % working with one source at a time
source_type = 1 ; % 1 = teleseismic
n_paths = 2 ; % computing two paths for each source (Ps, P)
n_segs = 2 ; % number of segments for each path (1 below interface, 1 above)

fprintf(fid,'%d\n',nevt);
fprintf(fid,'%d\n',source_type);
fprintf(fid,'%s\n',phase) ; % print teleseismic phase

% print source location (in km depth, degrees)
fprintf(fid,'%4.6f %4.6f %4.6f\n',evdep,evlat,evlon);

% Print number of paths (number of stations times number of paths per sta)
fprintf(fid,'%d\n',nsta*n_paths); 

for i = 1:nsta
    % print path information for path 1 (direct P)
    fprintf(fid,'%d\n',n_segs);
    fprintf(fid,'3 2 2 1\n') ; % path sequence (bottom to moho, moho to surface)
    fprintf(fid,'1 1\n') ; % velocity types in each segment (Vp for both)

    % print path information for path 2 (P-s)
    fprintf(fid,'%d\n',n_segs);
    fprintf(fid,'3 2 2 1\n') ; % path sequence (bottom to moho, moho to surface)
    fprintf(fid,'1 2\n') ; % velocity types in each segment (Vp to Vs at moho)
end
fclose(fid) ;

%% Write receiver input file
% initialize receivers.in
fid = fopen('receivers.in','w+') ;

fprintf(fid,'%d\n',nsta);

for j = 1:nsta
    % print station location (in km depth, degrees)
    fprintf(fid,'%4.3f %4.6f %4.6f\n',staelkm(j),stalat(j),stalon(j));

    fprintf(fid,'%d\n',n_paths); % number of paths for this station
    fprintf(fid,'1 1\n'); % source for each path
    fprintf(fid,'1 2\n'); % path number from each path for this station
end
fclose(fid) ;

end