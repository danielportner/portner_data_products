% plotMultCrosses plots multiple W-E cross sections across an iteration of
%   an inversion
%
% Written DEP 8 May 2020

%% Define variables

% Set map limits in km
h_bounds = [ -30 30 ] ;
v_bounds = [ domain.zmin domain.zmax ] ;

% Upsampling distances
msamp = 0.25 ; % Sampling distance for Moho
nsamp = 0.25 ; % Sampling distance for par in x, y, and z

% Choose cross sections to plot (y distance in km)
ycrosses = [ -20 -10 0 10 20 ] ; % Must correspond to y nodes in domain.mody

% choose which iterations to plot - last value should be chosen iteration
iter = 3 ;

% Set color axis limits
vcmin = 2.2 ; vcmax = 5.2 ; % Axis limits for velocity plots, in km/s
rcmin = 0.0 ; rcmax = 0.5 ; % Axis limits for R diagonal plots

%% Set up plots

% Create sample grid
hvals = [ h_bounds(1):nsamp:h_bounds(2) ] ;
vvals = [ v_bounds(1):nsamp:v_bounds(2) ] ;
[ hgrd, vgrd ] = meshgrid(hvals,vvals) ;

for k = 1:length(ycrosses)
    ycross = ycrosses(k) ;
    subplot(2,length(ycrosses),k)
    l = iter ;
    par = vms(:,l) ;
    par_plot = zeros(size(hgrd)) ;
    for iii = 1:length(hvals)
        for jjj = 1:length(vvals)
            n_indx = findNodes(hgrd(iii,jjj),ycross,vgrd(iii,jjj),domain) ;
            wts = nodeWeights(hgrd(iii,jjj),ycross,vgrd(iii,jjj),n_indx,domain) ;
            vij = sum(par(n_indx).*wts) ;
            par_plot(iii,jjj) = vij ;
        end
    end
    indx = find(domain.my == ycross & domain.mx>=h_bounds(1) & domain.mx<=h_bounds(2)) ;
    h = domain.mx(indx) ; nh = length(unique(h)) ;
    v = domain.mz(indx) ; nv = length(unique(v)) ;
    par2 = par(indx) ;
    colormap(flipud(jet)) ;
    image(h_bounds,v_bounds,par_plot,'CDataMapping','scaled')
    hold on
    scatter(h,v,10,'k','filled') ;
    set(gca,'YDir','reverse') 
    caxis([vcmin vcmax]) ;
    title(sprintf('Y = %02d km, iter = %01d',ycross,l))  ;
    xlabel('X distance (km)') ;
    ylabel('Depth (km)') ;
    c = colorbar;
    c.Label.String = 'Absolute Vs (km/s)';
    daspect([1 1 1])
    hold on
    
    % Plot Moho
    indx2 = find(Moho.y == ycross & Moho.x>=h_bounds(1) & Moho.x<=h_bounds(2)) ;
    [ xplot, m_indx ] = sort(Moho.x(indx2)) ;
    mplot_tmp = Moho.depth(indx2) ;
    mplot = mplot_tmp(m_indx) ;
    xplot_int = min(xplot):msamp:max(xplot) ;
    mplot_int = interp1(xplot,mplot,xplot_int,'pchip') ;
    plot(xplot_int,mplot_int,'k','LineWidth',2)
    
    % Plot Elevation
    eplot_tmp = Moho.elevs(indx2) ;
    eplot = eplot_tmp(m_indx) ;
    eplot_int = interp1(xplot,eplot,xplot_int,'pchip') ;
    plot(xplot_int,-1*eplot_int,'k','LineWidth',2)
    
    subplot(2,length(ycrosses),k+length(ycrosses))
    par = Rdiags(:,l) ;
    par_plot = zeros(size(hgrd)) ;
    for iii = 1:length(hvals)
        for jjj = 1:length(vvals)
            n_indx = findNodes(hgrd(iii,jjj),ycross,vgrd(iii,jjj),domain) ;
            wts = nodeWeights(hgrd(iii,jjj),ycross,vgrd(iii,jjj),n_indx,domain) ;
            vij = sum(par(n_indx).*wts) ;
            par_plot(iii,jjj) = vij ;
        end
    end
    par2 = par(indx) ;
    colormap(flipud(jet)) ;
    image(h_bounds,v_bounds,par_plot,'CDataMapping','scaled')
    hold on
    scatter(h,v,10,'k','filled') ;
    set(gca,'YDir','reverse') 
    caxis([rcmin rcmax]) ;
    title(sprintf('Y = %02d km, iter = %01d',ycross,l))  ;
    xlabel('X distance (km)') ;
    ylabel('Depth (km)') ;
    c = colorbar;
    c.Label.String = 'R diagonal';
    daspect([1 1 1])
    hold on
    
    % Plot Moho
    plot(xplot_int,mplot_int,'k','LineWidth',2)
      
    % Plot Elevation
    plot(xplot_int,-1*eplot_int,'k','LineWidth',2)
end

set(gcf, 'Position',  [100, 100, 400*length(ycrosses), 600])