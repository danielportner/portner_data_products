% plotIterTrade plots the tradeoff curves of an inversion over many
%   iterations using variance as the measure of fit
%
% Written DEP 8 May 2020

%% Plot

xvar = norm_mns(1:end-1) ;
zvar = 1:(n_iter-1) ;
dtmp = delay-d_preds(:,1) ;
k_indx = find(dtmp>=(-1*cutoff)&dtmp<=cutoff) ;
yvar0 = var(dtmp(k_indx)) ;
yvar1 = zeros(size(xvar)) ;
yvar2 = zeros(size(xvar)) ;
for ii = 1:(n_iter-1)
    dtmp = delay-d_preds(:,ii+1) ;
    if use_cutoff == true
        k_indx = find(dtmp>(-1*cutoff)&dtmp<cutoff) ;
    else
        k_indx = 1:lenght(dtmp) ;
    end
    yvar1(ii) = var(dtmp(k_indx)) ;
    yvar2(ii) = var(ds(:,ii)-dfs(:,ii)) ;
end

tstr = 'Iteration tradeoff' ;

xoff = 0.1 ;
yoff = 0 ;

% Plot yvar1
scatter([0],yvar0,50,'black') ;
title(tstr) ;
xlabel('L2 model norm (dVs/Vs)') ;
ylabel('Data misfit variance (s^2)') ;
hold on

% Plot yvar1 
scatter(xvar,yvar1,50,'black','filled') ;

% Plot text labels
for i = 1:length(zvar)
    text(xvar(i)+xoff,yvar1(i)+yoff,num2str(zvar(i))) ;
end

legend('Initial residuals','New predicted residuals')