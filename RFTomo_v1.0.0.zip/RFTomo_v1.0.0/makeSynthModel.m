% makeSynthModel is a script that uses an already established domain and
%   starting model to create a specified synthetic model
%
% Written DEP 29 Feb 2020

type_1 = 1 ; % Column 
type_2 = 1 ; % Second column
type_3 = 1 ; % Third column
type_4 = 1 ; % Fourth column
type_5 = 1 ; % Fifth column
type_6 = 1 ; % Sixth column

if type_1 == 1
    v_type = 2 ; % 2 for Vs
    dv = -0.50 ; % fractional velocity perturbation
    x_cond = [ 0 0 ] ; % x dimensions of slow conduit
    y_cond = [ 0 0 ] ; % y dimensions of slow conduit
    z_cond = [ 0 30 ] ; % z dimensions of slow conduit
    
    % find parameters affected
    indx = find(domain.mx >= x_cond(1) & domain.mx <= x_cond(2) & ...
        domain.my >= y_cond(1) & domain.my <= y_cond(2) & ...
        domain.mz >= z_cond(1) & domain.mz <= z_cond(2)) ;
    synth_model = smodel ;
    synth_model(indx,v_type) = synth_model(indx,v_type)*(1+dv) ;
    
end
if type_2 == 1
    v_type = 2 ; % 2 for Vs
    dv = -0.50 ; % fractional velocity perturbation
    x_cond = [ 10 10 ] ; % x dimensions of slow conduit
    y_cond = [ -10 -10 ] ; % y dimensions of slow conduit
    z_cond = [ 30 30 ] ; % z dimensions of slow conduit
    
    % find parameters affected
    indx = find(domain.mx >= x_cond(1) & domain.mx <= x_cond(2) & ...
        domain.my >= y_cond(1) & domain.my <= y_cond(2) & ...
        domain.mz >= z_cond(1) & domain.mz <= z_cond(2)) ;
    synth_model(indx,v_type) = synth_model(indx,v_type)*(1+dv) ;
end
if type_3 == 1
    v_type = 2 ; % 2 for Vs
    dv = 0.35 ; % fractional velocity perturbation
    x_cond = [ 10 10 ] ; % x dimensions of slow conduit
    y_cond = [ 0 0 ] ; % y dimensions of slow conduit
    z_cond = [ 0 20 ] ; % z dimensions of slow conduit
    
    % find parameters affected
    indx = find(domain.mx >= x_cond(1) & domain.mx <= x_cond(2) & ...
        domain.my >= y_cond(1) & domain.my <= y_cond(2) & ...
        domain.mz >= z_cond(1) & domain.mz <= z_cond(2)) ;
    synth_model(indx,v_type) = synth_model(indx,v_type)*(1+dv) ;
end
if type_4 == 1
    v_type = 2 ; % 2 for Vs
    dv = 0.35 ; % fractional velocity perturbation
    x_cond = [ 20 20 ] ; % x dimensions of slow conduit
    y_cond = [ 0 0 ] ; % y dimensions of slow conduit
    z_cond = [ 20 30 ] ; % z dimensions of slow conduit
    
    % find parameters affected
    indx = find(domain.mx >= x_cond(1) & domain.mx <= x_cond(2) & ...
        domain.my >= y_cond(1) & domain.my <= y_cond(2) & ...
        domain.mz >= z_cond(1) & domain.mz <= z_cond(2)) ;
    synth_model(indx,v_type) = synth_model(indx,v_type)*(1+dv) ;
end
if type_5 == 1
    v_type = 2 ; % 2 for Vs
    dv = 0.35 ; % fractional velocity perturbation
    x_cond = [ -10 -10 ] ; % x dimensions of slow conduit
    y_cond = [ -10 -10 ] ; % y dimensions of slow conduit
    z_cond = [ 0 30 ] ; % z dimensions of slow conduit
    
    % find parameters affected
    indx = find(domain.mx >= x_cond(1) & domain.mx <= x_cond(2) & ...
        domain.my >= y_cond(1) & domain.my <= y_cond(2) & ...
        domain.mz >= z_cond(1) & domain.mz <= z_cond(2)) ;
    synth_model(indx,v_type) = synth_model(indx,v_type)*(1+dv) ;
end
if type_6 == 1
    v_type = 2 ; % 2 for Vs
    dv = 0.35 ; % fractional velocity perturbation
    x_cond = [ -10 -10 ] ; % x dimensions of slow conduit
    y_cond = [ 10 10 ] ; % y dimensions of slow conduit
    z_cond = [ 0 30 ] ; % z dimensions of slow conduit
    
    % find parameters affected
    indx = find(domain.mx >= x_cond(1) & domain.mx <= x_cond(2) & ...
        domain.my >= y_cond(1) & domain.my <= y_cond(2) & ...
        domain.mz >= z_cond(1) & domain.mz <= z_cond(2)) ;
    synth_model(indx,v_type) = synth_model(indx,v_type)*(1+dv) ;
end