function [ ray_p,ray_s ] = getRays(rayFile)

% Reads arrivals.dat to retrieve the predicted P and Ps
%   travel times
%
% Written DEP 25 Feb 2020
% Edited DEP 20 Mar 2020 to accommodate multiple stations in output file

% open file
fid = fopen(rayFile,'r') ;
A = textscan(fid,'%f %f %s %s %f') ;
fclose(fid) ;

% Separate columns from input into variables
c1 = A{1} ; % contains header and radius
c2 = A{2} ; % contains header and lat
c3 = A{3} ; % contains header and lon
c4 = A{4} ; % contains header
c5 = A{5} ; % contains header

lines = length(c1) ;

n = 1 ;
m = 1 ;
while n <= lines
    if ~isnan(c5(n))
        ipath = str2double(c3{n}) ;
        ista = c1(n) ;
    elseif c3{n} == 'F'
        n_seg = c1(n) ;
        if c2(n) == 1
            use = 1 ;
            m = 1 ;
            if ipath == 1
                ray_pi = zeros(n_seg,3) ;
            elseif ipath == 2
                ray_si = zeros(n_seg,3) ;
            end
        elseif c2(n) == 2
            use = 0 ;
        end
    else
        if use == 1
            if ipath == 1
                ray_pi(m,1) = c1(n) ;
                ray_pi(m,2) = c2(n) ;
                ray_pi(m,3) = str2double(c3{n}) ;
                if m == n_seg
                    ray_p{ista} = ray_pi ;
                end
            elseif ipath == 2
                ray_si(m,1) = c1(n) ;
                ray_si(m,2) = c2(n) ;
                ray_si(m,3) = str2double(c3{n}) ;  
                if m == n_seg
                    ray_s{ista} = ray_si ;
                end
            end
            m = m + 1 ;
        end
    end
    n = n + 1 ;
end

end