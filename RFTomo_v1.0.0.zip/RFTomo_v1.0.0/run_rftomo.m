%---------- run_rftomo ----------%
%
% run_rftomo is a simple call script for a single run of rftomo
%   Parameters are defined herein
%

%% Define parameters
% Data file
delayFile = 'InputFiles/sampleInput_cleveland.dat' ; % Input data file

% Inversion parameters
n_iter = 5 ;

% data residual cutoff (s) - negative will be -1*cutoff
use_cutoff = true ; cutoff = 1.0 ;

% Damping
damp = 20 ; % epsilon^2 damping parameter

% Model domain parameters
origin = [ 52.82 -169.95 ] ; % Reference point for model domain [ lat lon ]
dx = 10 ; dy = 10 ; dz = 10 ; % Node spacing in x, y, and z dimensions
pad = 30 ; % Lateral distance beyond stations for model domain 
zrange = [ -10 50 ] ; % Depth range for model (negative is above sea level)

% Velocity model parameters
% vmod: refmod 1 = ak135, 2 = uniform crust with assigned Vs 
%   vmod = 2 requires a vs_crust value
vmod = 2  ; 
vs_crust = 3.7 ; % only for vmod = 2
% moho_type: 1 = flat Moho, 2 = pseudo-isostatic Moho, 3 = variable center Moho
moho_type = 3 ; 
smoho = 36 ; % Starting moho depth (for moho_type 2, is Moho at sea level)
mcent = 44 ; % Model center Moho - only needed for Moho_type = 3

%% Run rftomo
rftomo_v1_0_0
save('Saved/tmp.mat','-v7.3') ;
