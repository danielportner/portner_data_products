function [ model ] = getStartModel(vmod,Moho,domain)

% Based on defined Moho type, produces a starting velocity model over the
%   provided domain
%
% Written DEP 9 Apr 2020
% 

model = zeros(domain.nmod,2) ;
% Do interpolation for each surficial grid node
%   This assumes vertical grid columns
for i = 1:domain.nx
    gx = domain.modx(i) ;
    for j = 1:domain.ny
        gy = domain.mody(j) ;
        gindx = find(domain.mx == gx & domain.my == gy) ;
        % Find Moho for this grid node and do 1D interpolation
        moho = Moho.depth(Moho.x == gx & Moho.y == gy) ;
        velij = interpvel1D(vmod,3,moho,domain.vs_crust,domain.modz') ;
        % Populate model for that grid node
        model(gindx,1) = velij(:,1) ;
        model(gindx,2) = velij(:,2) ;
    end
end

end